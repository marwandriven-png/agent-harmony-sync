"""
LeadM8 Call System - CRM Integration SDK

This module provides easy integration methods for your CRM backend.
Import these functions into your existing CRM code to interact with the call system.

Usage:
    from call_system.crm_integration import CallSystemClient

    client = CallSystemClient(base_url="https://your-api.com", api_key="secret")
    client.initiate_call(lead_id=123, agent_id=5, phone_number="+1234567890")
"""

import requests
from typing import Dict, Any, Optional, List
from datetime import datetime


class CallSystemClient:
    """
    Client for interacting with LeadM8 Call System API
    """

    def __init__(self, base_url: str, api_key: str, timeout: int = 30):
        self.base_url = base_url.rstrip('/')
        self.headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        self.timeout = timeout

    def initiate_call(self, lead_id: int, agent_id: int, 
                     phone_number: str, recording_enabled: bool = True) -> Dict[str, Any]:
        """Initiate a call from CRM"""
        response = requests.post(
            f"{self.base_url}/api/calls/initiate",
            headers=self.headers,
            json={
                'lead_id': lead_id,
                'agent_id': agent_id,
                'phone_number': phone_number,
                'recording_enabled': recording_enabled
            },
            timeout=self.timeout
        )
        response.raise_for_status()
        return response.json()

    def get_call_status(self, call_id: int) -> Dict[str, Any]:
        """Get current status of a call"""
        response = requests.get(
            f"{self.base_url}/api/calls/{call_id}/status",
            headers=self.headers,
            timeout=self.timeout
        )
        response.raise_for_status()
        return response.json()

    def list_calls_for_lead(self, lead_id: int, limit: int = 50) -> List[Dict[str, Any]]:
        """Get all calls for a specific lead"""
        response = requests.get(
            f"{self.base_url}/api/called-calls",
            headers=self.headers,
            params={'lead_id': lead_id, 'limit': limit},
            timeout=self.timeout
        )
        response.raise_for_status()
        data = response.json()
        return data.get('calls', [])

    def get_ai_evaluation(self, call_id: int) -> Dict[str, Any]:
        """Get AI evaluation results for a call"""
        response = requests.get(
            f"{self.base_url}/api/calls/{call_id}/full-analysis",
            headers=self.headers,
            timeout=self.timeout
        )
        response.raise_for_status()
        return response.json()

    def get_agent_weekly_kpi(self, agent_id: int) -> Dict[str, Any]:
        """Get weekly KPIs for an agent"""
        response = requests.get(
            f"{self.base_url}/api/agents/{agent_id}/kpi/weekly",
            headers=self.headers,
            timeout=self.timeout
        )
        response.raise_for_status()
        return response.json()


def format_call_for_crm_display(call_data: Dict[str, Any]) -> Dict[str, Any]:
    """Format call data for display in CRM UI"""
    return {
        'id': call_data.get('id'),
        'lead_id': call_data.get('lead_id'),
        'agent_id': call_data.get('agent_id'),
        'phone': call_data.get('phone_number'),
        'direction': call_data.get('direction'),
        'status': call_data.get('status'),
        'date': call_data.get('call_date'),
        'duration': call_data.get('duration_seconds', 0),
        'has_recording': bool(call_data.get('recording_url')),
        'has_transcript': call_data.get('transcript_status') == 'completed',
        'ai_score': call_data.get('ai_overall_score'),
        'ai_evaluation_complete': call_data.get('ai_evaluation_status') == 'completed'
    }

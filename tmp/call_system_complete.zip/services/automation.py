"""
Automation & Workflow Service
Handles automated triggers after call events
Manages the pipeline: Call -> Transcription -> AI Evaluation -> KPIs
"""
import logging
from typing import Dict, Any, Optional
from sqlalchemy.orm import Session
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from models import CalledCall, CallStatus
from services.transcription import transcription_service
from services.ai_evaluation import ai_evaluation_service
from services.kpi import kpi_service
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class AutomationService:
    """
    Workflow automation engine
    Triggers actions based on call events and schedules
    """

    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self._setup_scheduled_jobs()
        self.scheduler.start()
        logger.info("Automation scheduler started")

    def _setup_scheduled_jobs(self):
        """Setup periodic KPI calculation jobs"""
        # Weekly KPIs - every Monday at 2 AM
        self.scheduler.add_job(
            self._calculate_all_weekly_kpis,
            CronTrigger(day_of_week='mon', hour=2, minute=0),
            id='weekly_kpi_calculation',
            replace_existing=True
        )

        # Monthly KPIs - 1st of every month at 3 AM
        self.scheduler.add_job(
            self._calculate_all_monthly_kpis,
            CronTrigger(day=1, hour=3, minute=0),
            id='monthly_kpi_calculation',
            replace_existing=True
        )

        # Process pending transcriptions - every 5 minutes
        self.scheduler.add_job(
            self._process_pending_transcriptions,
            'interval', minutes=5,
            id='pending_transcriptions',
            replace_existing=True
        )

        # Process pending AI evaluations - every 10 minutes
        self.scheduler.add_job(
            self._process_pending_evaluations,
            'interval', minutes=10,
            id='pending_evaluations',
            replace_existing=True
        )

    def handle_call_completed(self, call_id: int, db: Session) -> Dict[str, Any]:
        """
        Triggered when a call ends
        Initiates transcription workflow
        """
        try:
            call = db.query(CalledCall).filter(CalledCall.id == call_id).first()
            if not call:
                return {'success': False, 'error': 'Call not found'}

            # Only process if call was answered and has recording
            if call.status not in [CallStatus.COMPLETED, CallStatus.ANSWERED]:
                return {'success': True, 'message': 'Call not answered, skipping'}

            if not call.recording_url:
                return {'success': True, 'message': 'No recording, skipping'}

            # Trigger transcription
            logger.info(f"Triggering transcription for call {call_id}")
            result = transcription_service.transcribe_call(call_id, db)

            if result['success']:
                # If transcription successful, trigger AI evaluation
                logger.info(f"Transcription complete, triggering AI evaluation for call {call_id}")
                self._trigger_ai_evaluation(call_id, db)

            return {
                'success': True,
                'call_id': call_id,
                'transcription': result,
                'workflow': 'Call -> Transcription -> AI Evaluation initiated'
            }

        except Exception as e:
            logger.error(f"Call completion automation error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def _trigger_ai_evaluation(self, call_id: int, db: Session):
        """Trigger AI evaluation after transcription"""
        try:
            call = db.query(CalledCall).filter(CalledCall.id == call_id).first()
            if call and call.transcript_text:
                ai_evaluation_service.evaluate_call(call_id, db)
        except Exception as e:
            logger.error(f"AI evaluation trigger error: {str(e)}")

    def _process_pending_transcriptions(self):
        """Background job: Process calls with pending transcription"""
        from database import SessionLocal

        try:
            db = SessionLocal()
            pending_calls = db.query(CalledCall).filter(
                CalledCall.transcript_status == 'pending',
                CalledCall.recording_url.isnot(None)
            ).limit(10).all()

            for call in pending_calls:
                logger.info(f"Auto-processing transcription for call {call.id}")
                transcription_service.transcribe_call(call.id, db)

        except Exception as e:
            logger.error(f"Pending transcription processing error: {str(e)}")
        finally:
            db.close()

    def _process_pending_evaluations(self):
        """Background job: Process calls with pending AI evaluation"""
        from database import SessionLocal

        try:
            db = SessionLocal()
            pending_calls = db.query(CalledCall).filter(
                CalledCall.ai_evaluation_status == 'pending',
                CalledCall.transcript_status == 'completed'
            ).limit(5).all()  # Limit to avoid rate limits

            for call in pending_calls:
                logger.info(f"Auto-processing AI evaluation for call {call.id}")
                ai_evaluation_service.evaluate_call(call.id, db)

        except Exception as e:
            logger.error(f"Pending evaluation processing error: {str(e)}")
        finally:
            db.close()

    def _calculate_all_weekly_kpis(self):
        """Calculate weekly KPIs for all agents"""
        from database import SessionLocal

        try:
            db = SessionLocal()

            # Get all agents who had calls this week
            week_start = datetime.utcnow() - timedelta(days=datetime.utcnow().weekday())
            week_start = week_start.replace(hour=0, minute=0, second=0, microsecond=0)

            agent_ids = db.query(CalledCall.agent_id).filter(
                CalledCall.call_date >= week_start
            ).distinct().all()

            for (agent_id,) in agent_ids:
                logger.info(f"Calculating weekly KPIs for agent {agent_id}")
                kpi_service.calculate_weekly_kpis(agent_id, db, week_start)

        except Exception as e:
            logger.error(f"Weekly KPI calculation error: {str(e)}")
        finally:
            db.close()

    def _calculate_all_monthly_kpis(self):
        """Calculate monthly KPIs for all agents"""
        from database import SessionLocal

        try:
            db = SessionLocal()

            month_start = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)

            agent_ids = db.query(CalledCall.agent_id).filter(
                CalledCall.call_date >= month_start
            ).distinct().all()

            for (agent_id,) in agent_ids:
                logger.info(f"Calculating monthly KPIs for agent {agent_id}")
                kpi_service.calculate_monthly_kpis(agent_id, db, month_start)

        except Exception as e:
            logger.error(f"Monthly KPI calculation error: {str(e)}")
        finally:
            db.close()

    def manual_trigger_evaluation(self, call_id: int, db: Session) -> Dict[str, Any]:
        """
        Manual trigger for AI evaluation (for retry scenarios)
        """
        return ai_evaluation_service.evaluate_call(call_id, db)

    def manual_trigger_kpi(self, agent_id: int, period_type: str, db: Session) -> Dict[str, Any]:
        """
        Manual trigger for KPI calculation
        """
        if period_type == 'weekly':
            return kpi_service.calculate_weekly_kpis(agent_id, db)
        else:
            return kpi_service.calculate_monthly_kpis(agent_id, db)

    def get_workflow_status(self, call_id: int, db: Session) -> Dict[str, Any]:
        """
        Get current status of automation workflow for a call
        """
        call = db.query(CalledCall).filter(CalledCall.id == call_id).first()
        if not call:
            return {'success': False, 'error': 'Call not found'}

        return {
            'success': True,
            'call_id': call_id,
            'workflow': {
                'call_status': call.status.value if call.status else None,
                'recording': 'available' if call.recording_url else 'pending',
                'transcription': {
                    'status': call.transcript_status,
                    'provider': call.transcript_provider,
                    'has_text': bool(call.transcript_text)
                },
                'ai_evaluation': {
                    'status': call.ai_evaluation_status,
                    'scores': {
                        'overall': call.ai_overall_score,
                        'confidence': call.ai_confidence_score,
                        'lead_intent': call.ai_lead_intent_score,
                        'closing_probability': call.ai_closing_probability
                    } if call.ai_evaluation_status == 'completed' else None
                }
            }
        }

# Singleton instance
automation_service = AutomationService()

"""
AI Evaluation Service
Analyzes call transcripts using OpenAI GPT-4
Provides scoring and qualitative feedback
"""
import logging
import json
import requests
from typing import Dict, Any, List
from sqlalchemy.orm import Session
from models import CalledCall, AIEvaluationPrompt
from config import openai_config

logger = logging.getLogger(__name__)

class AIEvaluationService:
    """
    Service for AI-powered call evaluation
    Uses OpenAI GPT-4 to analyze transcripts
    """

    def __init__(self):
        self.api_key = openai_config.api_key
        self.model = openai_config.model
        self.max_tokens = openai_config.max_tokens
        self.temperature = openai_config.temperature

        # Default evaluation prompt
        self.default_prompt = """You are an expert sales call analyst. Evaluate the following sales call transcript and provide a detailed analysis.

Transcript:
{transcript}

Call Context:
- Direction: {direction}
- Duration: {duration} seconds
- Agent ID: {agent_id}

Provide your analysis in the following JSON format:
{{
    "overall_score": <number 0-100>,
    "confidence_score": <number 0-100>,
    "lead_intent_score": <number 0-100>,
    "closing_probability": <number 0-100>,
    "strengths": [
        "<specific strength with example from transcript>",
        "<another strength>"
    ],
    "weaknesses": [
        "<specific weakness with example from transcript>",
        "<another weakness>"
    ],
    "detailed_analysis": {{
        "communication_clarity": "<assessment>",
        "objection_handling": "<assessment>",
        "discovery_quality": "<how well they understood needs>",
        "closing_attempts": "<assessment of closing>",
        "missed_opportunities": "<what was missed>"
    }},
    "key_quotes": [
        "<important quote from transcript>"
    ],
    "recommendations": [
        "<actionable recommendation>"
    ]
}}

Scoring Guidelines:
- Overall Score: General quality of the call (0-100)
- Confidence Score: Agent's confidence and authority (0-100)
- Lead Intent Score: How interested the lead appears (0-100)
- Closing Probability: Likelihood of conversion (0-100)

Be objective and specific. Reference actual quotes from the transcript."""

    def evaluate_call(self, call_id: int, db: Session) -> Dict[str, Any]:
        """
        Main method to evaluate a call using AI

        Args:
            call_id: ID of the call in database
            db: Database session

        Returns:
            Evaluation results dict
        """
        try:
            # Get call record
            call = db.query(CalledCall).filter(CalledCall.id == call_id).first()
            if not call:
                return {'success': False, 'error': 'Call not found'}

            if not call.transcript_text:
                return {'success': False, 'error': 'No transcript available'}

            # Update status
            call.ai_evaluation_status = 'processing'
            db.commit()

            # Prepare prompt
            prompt = self._build_prompt(call)

            # Call OpenAI API
            result = self._call_openai(prompt)

            if result['success']:
                # Parse and store results
                self._store_evaluation(call, result['analysis'], db)

                logger.info(f"AI evaluation completed for call {call_id}")
                return {
                    'success': True,
                    'call_id': call_id,
                    'scores': {
                        'overall': call.ai_overall_score,
                        'confidence': call.ai_confidence_score,
                        'lead_intent': call.ai_lead_intent_score,
                        'closing_probability': call.ai_closing_probability
                    }
                }
            else:
                call.ai_evaluation_status = 'failed'
                db.commit()
                return result

        except Exception as e:
            logger.error(f"AI evaluation error for call {call_id}: {str(e)}")
            call.ai_evaluation_status = 'failed'
            db.commit()
            return {'success': False, 'error': str(e)}

    def _build_prompt(self, call: CalledCall) -> str:
        """Build evaluation prompt with transcript data"""
        return self.default_prompt.format(
            transcript=call.transcript_text[:8000],  # Limit length
            direction=call.direction.value,
            duration=call.duration_seconds or 0,
            agent_id=call.agent_id
        )

    def _call_openai(self, prompt: str) -> Dict[str, Any]:
        """Make OpenAI API call"""
        try:
            headers = {
                'Authorization': f'Bearer {self.api_key}',
                'Content-Type': 'application/json'
            }

            payload = {
                'model': self.model,
                'messages': [
                    {
                        'role': 'system',
                        'content': 'You are a professional sales call analyst. Provide objective, detailed analysis.'
                    },
                    {
                        'role': 'user',
                        'content': prompt
                    }
                ],
                'max_tokens': self.max_tokens,
                'temperature': self.temperature,
                'response_format': {'type': 'json_object'}
            }

            response = requests.post(
                'https://api.openai.com/v1/chat/completions',
                headers=headers,
                json=payload,
                timeout=60
            )

            if response.status_code == 200:
                result = response.json()
                content = result['choices'][0]['message']['content']

                try:
                    analysis = json.loads(content)
                    return {
                        'success': True,
                        'analysis': analysis
                    }
                except json.JSONDecodeError:
                    return {
                        'success': False,
                        'error': 'Failed to parse AI response as JSON',
                        'raw_response': content
                    }
            else:
                return {
                    'success': False,
                    'error': f'OpenAI API error: {response.status_code}',
                    'details': response.text
                }

        except Exception as e:
            logger.error(f"OpenAI API call error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def _store_evaluation(self, call: CalledCall, analysis: Dict, db: Session):
        """Store AI evaluation results in database"""
        try:
            # Extract scores
            call.ai_overall_score = float(analysis.get('overall_score', 0))
            call.ai_confidence_score = float(analysis.get('confidence_score', 0))
            call.ai_lead_intent_score = float(analysis.get('lead_intent_score', 0))
            call.ai_closing_probability = float(analysis.get('closing_probability', 0))

            # Extract lists
            call.ai_strengths = analysis.get('strengths', [])
            call.ai_weaknesses = analysis.get('weaknesses', [])

            # Store full analysis
            call.ai_full_analysis = analysis
            call.ai_evaluation_status = 'completed'

            db.commit()

        except Exception as e:
            logger.error(f"Error storing evaluation: {str(e)}")
            raise

    def batch_evaluate(self, call_ids: List[int], db: Session) -> Dict[str, Any]:
        """
        Evaluate multiple calls (for batch processing)
        """
        results = {
            'total': len(call_ids),
            'completed': 0,
            'failed': 0,
            'details': []
        }

        for call_id in call_ids:
            result = self.evaluate_call(call_id, db)
            if result['success']:
                results['completed'] += 1
            else:
                results['failed'] += 1
            results['details'].append(result)

        return results

    def get_evaluation_summary(self, call_id: int, db: Session) -> Dict[str, Any]:
        """Get human-readable evaluation summary"""
        call = db.query(CalledCall).filter(CalledCall.id == call_id).first()
        if not call or call.ai_evaluation_status != 'completed':
            return {'success': False, 'error': 'Evaluation not available'}

        return {
            'success': True,
            'call_id': call_id,
            'scores': {
                'overall': call.ai_overall_score,
                'confidence': call.ai_confidence_score,
                'lead_intent': call.ai_lead_intent_score,
                'closing_probability': call.ai_closing_probability
            },
            'strengths': call.ai_strengths,
            'weaknesses': call.ai_weaknesses,
            'full_analysis': call.ai_full_analysis
        }

# Singleton instance
ai_evaluation_service = AIEvaluationService()

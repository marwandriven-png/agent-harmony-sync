"""
KPI Service
Calculates weekly and monthly performance metrics
Generates reports and rankings
"""
import logging
from typing import Dict, Any, List, Optional
from sqlalchemy import func, and_
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from models import CalledCall, CallKPI, CallStatus, CallDirection
from collections import Counter
import json

logger = logging.getLogger(__name__)

class KPIService:
    """
    Service for calculating and managing KPI metrics
    """

    def calculate_weekly_kpis(self, agent_id: int, db: Session, 
                           week_start: Optional[datetime] = None) -> Dict[str, Any]:
        """
        Calculate weekly KPIs for an agent

        Args:
            agent_id: Agent/User ID
            db: Database session
            week_start: Start of week (defaults to current week)

        Returns:
            KPI data dict
        """
        if week_start is None:
            # Get start of current week (Monday)
            today = datetime.utcnow()
            week_start = today - timedelta(days=today.weekday())
            week_start = week_start.replace(hour=0, minute=0, second=0, microsecond=0)

        week_end = week_start + timedelta(days=7)

        return self._calculate_period_kpis(
            agent_id, 'weekly', week_start, week_end, db
        )

    def calculate_monthly_kpis(self, agent_id: int, db: Session,
                              month_start: Optional[datetime] = None) -> Dict[str, Any]:
        """
        Calculate monthly KPIs for an agent
        """
        if month_start is None:
            today = datetime.utcnow()
            month_start = today.replace(day=1, hour=0, minute=0, second=0, microsecond=0)

        # Calculate month end
        if month_start.month == 12:
            month_end = month_start.replace(year=month_start.year + 1, month=1)
        else:
            month_end = month_start.replace(month=month_start.month + 1)

        return self._calculate_period_kpis(
            agent_id, 'monthly', month_start, month_end, db
        )

    def _calculate_period_kpis(self, agent_id: int, period_type: str,
                            period_start: datetime, period_end: datetime,
                            db: Session) -> Dict[str, Any]:
        """
        Core KPI calculation logic
        """
        try:
            # Query calls in period
            calls = db.query(CalledCall).filter(
                and_(
                    CalledCall.agent_id == agent_id,
                    CalledCall.call_date >= period_start,
                    CalledCall.call_date < period_end,
                    CalledCall.status.in_([
                        CallStatus.COMPLETED,
                        CallStatus.ANSWERED,
                        CallStatus.MISSED,
                        CallStatus.BUSY,
                        CallStatus.REJECTED
                    ])
                )
            ).all()

            if not calls:
                logger.info(f"No calls found for agent {agent_id} in period")
                return {'success': True, 'data': None}

            # Calculate metrics
            total_calls = len(calls)
            inbound_calls = sum(1 for c in calls if c.direction == CallDirection.INBOUND)
            outbound_calls = sum(1 for c in calls if c.direction == CallDirection.OUTBOUND)

            answered_calls = sum(1 for c in calls if c.status in [CallStatus.ANSWERED, CallStatus.COMPLETED])
            missed_calls = sum(1 for c in calls if c.status == CallStatus.MISSED)

            # Duration metrics (only for answered calls)
            answered_with_duration = [c for c in calls if c.duration_seconds and c.duration_seconds > 0]
            total_duration = sum(c.duration_seconds for c in answered_with_duration)
            avg_duration = total_duration / len(answered_with_duration) if answered_with_duration else 0

            # Answer rate
            answer_rate = (answered_calls / total_calls * 100) if total_calls > 0 else 0

            # AI Score metrics (only evaluated calls)
            evaluated_calls = [c for c in calls if c.ai_evaluation_status == 'completed']

            avg_ai_score = 0
            high_intent_calls = 0
            weak_calls = 0

            if evaluated_calls:
                scores = [c.ai_overall_score for c in evaluated_calls if c.ai_overall_score]
                avg_ai_score = sum(scores) / len(scores) if scores else 0

                high_intent_calls = sum(1 for c in evaluated_calls 
                                      if c.ai_lead_intent_score and c.ai_lead_intent_score > 70)
                weak_calls = sum(1 for c in evaluated_calls 
                               if c.ai_overall_score and c.ai_overall_score < 50)

            # Aggregate strengths and weaknesses
            all_strengths = []
            all_weaknesses = []
            for c in evaluated_calls:
                if c.ai_strengths:
                    all_strengths.extend(c.ai_strengths)
                if c.ai_weaknesses:
                    all_weaknesses.extend(c.ai_weaknesses)

            # Get top 3 common strengths/weaknesses
            common_strengths = [item for item, _ in Counter(all_strengths).most_common(3)]
            common_weaknesses = [item for item, _ in Counter(all_weaknesses).most_common(3)]

            # Generate improvement suggestions
            suggestions = self._generate_suggestions(common_strengths, common_weaknesses, avg_ai_score)

            # Create or update KPI record
            kpi = db.query(CallKPI).filter(
                and_(
                    CallKPI.agent_id == agent_id,
                    CallKPI.period_type == period_type,
                    CallKPI.period_start == period_start
                )
            ).first()

            if not kpi:
                kpi = CallKPI(
                    agent_id=agent_id,
                    period_type=period_type,
                    period_start=period_start,
                    period_end=period_end
                )
                db.add(kpi)

            # Update KPI
            kpi.total_calls = total_calls
            kpi.inbound_calls = inbound_calls
            kpi.outbound_calls = outbound_calls
            kpi.answered_calls = answered_calls
            kpi.missed_calls = missed_calls
            kpi.total_duration_seconds = total_duration
            kpi.avg_duration_seconds = avg_duration
            kpi.avg_ai_score = avg_ai_score
            kpi.answer_rate = answer_rate
            kpi.high_intent_calls = high_intent_calls
            kpi.weak_calls = weak_calls
            kpi.common_strengths = common_strengths
            kpi.common_weaknesses = common_weaknesses
            kpi.improvement_suggestions = suggestions

            db.commit()

            return {
                'success': True,
                'kpi_id': kpi.id,
                'data': {
                    'period': {
                        'type': period_type,
                        'start': period_start.isoformat(),
                        'end': period_end.isoformat()
                    },
                    'volume': {
                        'total_calls': total_calls,
                        'inbound': inbound_calls,
                        'outbound': outbound_calls,
                        'answered': answered_calls,
                        'missed': missed_calls
                    },
                    'quality': {
                        'avg_duration_seconds': round(avg_duration, 2),
                        'avg_ai_score': round(avg_ai_score, 2),
                        'answer_rate': round(answer_rate, 2)
                    },
                    'performance': {
                        'high_intent_calls': high_intent_calls,
                        'weak_calls': weak_calls,
                        'common_strengths': common_strengths,
                        'common_weaknesses': common_weaknesses,
                        'improvement_suggestions': suggestions
                    }
                }
            }

        except Exception as e:
            logger.error(f"KPI calculation error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def get_agent_ranking(self, db: Session, period_type: str = 'monthly',
                         period_start: Optional[datetime] = None) -> Dict[str, Any]:
        """
        Get agent rankings for a period
        """
        try:
            if period_start is None:
                if period_type == 'weekly':
                    today = datetime.utcnow()
                    period_start = today - timedelta(days=today.weekday())
                else:
                    today = datetime.utcnow()
                    period_start = today.replace(day=1)

            kpis = db.query(CallKPI).filter(
                and_(
                    CallKPI.period_type == period_type,
                    CallKPI.period_start == period_start
                )
            ).order_by(CallKPI.avg_ai_score.desc()).all()

            rankings = []
            for rank, kpi in enumerate(kpis, 1):
                rankings.append({
                    'rank': rank,
                    'agent_id': kpi.agent_id,
                    'total_calls': kpi.total_calls,
                    'avg_ai_score': round(kpi.avg_ai_score, 2),
                    'answer_rate': round(kpi.answer_rate, 2),
                    'high_intent_calls': kpi.high_intent_calls,
                    'weak_calls': kpi.weak_calls
                })

            return {
                'success': True,
                'period': {
                    'type': period_type,
                    'start': period_start.isoformat()
                },
                'rankings': rankings
            }

        except Exception as e:
            logger.error(f"Ranking error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def get_performance_trends(self, agent_id: int, weeks: int = 4, db: Session) -> Dict[str, Any]:
        """
        Get performance trends over time
        """
        try:
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(weeks=weeks)

            kpis = db.query(CallKPI).filter(
                and_(
                    CallKPI.agent_id == agent_id,
                    CallKPI.period_type == 'weekly',
                    CallKPI.period_start >= start_date,
                    CallKPI.period_start <= end_date
                )
            ).order_by(CallKPI.period_start).all()

            trends = {
                'dates': [k.period_start.isoformat() for k in kpis],
                'total_calls': [k.total_calls for k in kpis],
                'avg_ai_scores': [round(k.avg_ai_score, 2) for k in kpis],
                'answer_rates': [round(k.answer_rate, 2) for k in kpis],
                'avg_durations': [round(k.avg_duration_seconds, 2) for k in kpis]
            }

            return {
                'success': True,
                'agent_id': agent_id,
                'weeks_analyzed': weeks,
                'trends': trends
            }

        except Exception as e:
            logger.error(f"Trends error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def export_report(self, agent_id: int, period_type: str, 
                     period_start: datetime, format: str, db: Session) -> Dict[str, Any]:
        """
        Export KPI report in CSV or JSON format
        """
        try:
            kpi = db.query(CallKPI).filter(
                and_(
                    CallKPI.agent_id == agent_id,
                    CallKPI.period_type == period_type,
                    CallKPI.period_start == period_start
                )
            ).first()

            if not kpi:
                return {'success': False, 'error': 'KPI data not found'}

            report_data = {
                'agent_id': agent_id,
                'period': {
                    'type': period_type,
                    'start': period_start.isoformat(),
                    'end': kpi.period_end.isoformat()
                },
                'metrics': {
                    'total_calls': kpi.total_calls,
                    'inbound_calls': kpi.inbound_calls,
                    'outbound_calls': kpi.outbound_calls,
                    'answered_calls': kpi.answered_calls,
                    'missed_calls': kpi.missed_calls,
                    'total_duration_seconds': kpi.total_duration_seconds,
                    'avg_duration_seconds': kpi.avg_duration_seconds,
                    'answer_rate': kpi.answer_rate,
                    'avg_ai_score': kpi.avg_ai_score,
                    'high_intent_calls': kpi.high_intent_calls,
                    'weak_calls': kpi.weak_calls
                },
                'analysis': {
                    'common_strengths': kpi.common_strengths,
                    'common_weaknesses': kpi.common_weaknesses,
                    'improvement_suggestions': kpi.improvement_suggestions
                },
                'generated_at': datetime.utcnow().isoformat()
            }

            if format.lower() == 'csv':
                # Convert to CSV format
                csv_data = self._convert_to_csv(report_data)
                return {
                    'success': True,
                    'format': 'csv',
                    'data': csv_data
                }
            else:
                return {
                    'success': True,
                    'format': 'json',
                    'data': report_data
                }

        except Exception as e:
            logger.error(f"Export error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def _generate_suggestions(self, strengths: List[str], weaknesses: List[str], avg_score: float) -> str:
        """Generate improvement suggestions based on analysis"""
        suggestions = []

        if avg_score < 50:
            suggestions.append("Priority: Focus on fundamental sales techniques. Consider additional training.")
        elif avg_score < 70:
            suggestions.append("Continue developing core skills. Review top performer recordings.")
        else:
            suggestions.append("Strong performance. Mentor other team members.")

        if weaknesses:
            suggestions.append(f"Focus areas: {', '.join(weaknesses[:2])}")

        if not strengths:
            suggestions.append("Work on building rapport and asking discovery questions.")

        return " | ".join(suggestions)

    def _convert_to_csv(self, report_data: Dict) -> str:
        """Convert report to CSV string"""
        import csv
        import io

        output = io.StringIO()
        writer = csv.writer(output)

        # Header
        writer.writerow(['Metric', 'Value'])

        # Basic info
        writer.writerow(['Agent ID', report_data['agent_id']])
        writer.writerow(['Period Type', report_data['period']['type']])
        writer.writerow(['Period Start', report_data['period']['start']])
        writer.writerow(['Period End', report_data['period']['end']])
        writer.writerow([])

        # Metrics
        writer.writerow(['METRICS'])
        for key, value in report_data['metrics'].items():
            writer.writerow([key, value])

        return output.getvalue()

# Singleton instance
kpi_service = KPIService()

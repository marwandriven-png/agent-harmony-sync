"""
Call Provider Service
Handles Twilio/CallGear API integration for call initiation and webhooks
"""
import logging
from typing import Optional, Dict, Any
from twilio.rest import Client
from twilio.twiml.voice_response import VoiceResponse, Dial
from sqlalchemy.orm import Session
from models import CalledCall, CallDirection, CallStatus, CallWebhookLog
from config import call_provider_config, app_config
from datetime import datetime

logger = logging.getLogger(__name__)

class CallProviderService:
    """
    Service for managing calls via Twilio/CallGear
    Handles click-to-call, incoming calls, and webhooks
    """

    def __init__(self):
        self.client = Client(
            call_provider_config.account_sid,
            call_provider_config.auth_token
        )
        self.from_number = call_provider_config.from_number

    def initiate_call(self, 
                     to_number: str, 
                     lead_id: int, 
                     agent_id: int,
                     recording_enabled: bool = True) -> Dict[str, Any]:
        """
        Initiate outbound call from CRM (Click-to-Call)

        Args:
            to_number: Phone number to call (E.164 format)
            lead_id: CRM Lead ID
            agent_id: CRM Agent/User ID
            recording_enabled: Whether to record the call

        Returns:
            Dict with call_sid, status, and CRM call record ID
        """
        try:
            # Format phone number if needed
            if not to_number.startswith('+'):
                to_number = '+' + to_number

            # Build webhook URL for status updates
            status_callback_url = f"{self._get_base_url()}/webhooks/call-status"

            # Create call via Twilio
            call = self.client.calls.create(
                to=to_number,
                from_=self.from_number,
                url=f"{self._get_base_url()}/twiml/connect-agent?agent_id={agent_id}",
                status_callback=status_callback_url,
                status_callback_event=['initiated', 'ringing', 'answered', 'completed'],
                status_callback_method='POST',
                record=recording_enabled,
                recording_status_callback=f"{self._get_base_url()}/webhooks/recording",
                recording_status_callback_method='POST',
                machine_detection='Enable',  # Detect voicemail
                trim='trim-silence'  # Remove silence from recording
            )

            logger.info(f"Call initiated: {call.sid} to {to_number}")

            return {
                'success': True,
                'call_sid': call.sid,
                'status': call.status,
                'direction': 'outbound'
            }

        except Exception as e:
            logger.error(f"Failed to initiate call: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }

    def generate_twiml_for_agent(self, agent_phone: str, lead_id: int) -> str:
        """
        Generate TwiML to connect agent to lead
        This is called when call is answered
        """
        response = VoiceResponse()

        # Whisper to agent who they're calling
        response.say(f"Connecting to lead {lead_id}", voice='alice')

        # Dial the agent's phone or connect to browser-based client
        dial = Dial(
            record='record-from-answer-dual',  # Stereo recording for better transcription
            recording_status_callback=f"{self._get_base_url()}/webhooks/recording",
            recording_status_callback_method='POST'
        )

        # If using browser-based calling, use client:agent_id
        # If using phone forwarding, use number
        if agent_phone.startswith('client:'):
            dial.client(agent_phone.replace('client:', ''))
        else:
            dial.number(agent_phone)

        response.append(dial)

        return str(response)

    def handle_call_webhook(self, 
                         payload: Dict[str, Any], 
                         db: Session) -> bool:
        """
        Process incoming webhooks from call provider
        Handles: call status updates, recording ready, etc.
        """
        try:
            event_type = payload.get('CallStatus') or payload.get('EventType')
            call_sid = payload.get('CallSid')

            # Log webhook
            webhook_log = CallWebhookLog(
                provider='twilio',
                event_type=event_type or 'unknown',
                payload=payload,
                processed=False
            )
            db.add(webhook_log)
            db.commit()

            # Find or create call record
            call_record = db.query(CalledCall).filter(
                CalledCall.provider_call_sid == call_sid
            ).first()

            if not call_record:
                # New call (likely inbound)
                call_record = CalledCall(
                    provider_call_sid=call_sid,
                    phone_number=payload.get('From') or payload.get('CustomerNumber'),
                    direction=CallDirection.INBOUND if payload.get('Direction') == 'inbound' else CallDirection.OUTBOUND,
                    status=self._map_status(event_type),
                    started_at=datetime.utcnow()
                )
                db.add(call_record)
            else:
                # Update existing
                call_record.status = self._map_status(event_type)

                if event_type in ['completed', 'busy', 'failed', 'no-answer']:
                    call_record.ended_at = datetime.utcnow()
                    if call_record.started_at:
                        duration = (call_record.ended_at - call_record.started_at).total_seconds()
                        call_record.duration_seconds = int(duration)

            webhook_log.processed = True
            webhook_log.processed_at = datetime.utcnow()
            db.commit()

            return True

        except Exception as e:
            logger.error(f"Webhook processing error: {str(e)}")
            webhook_log.error_message = str(e)
            db.commit()
            return False

    def handle_recording_webhook(self, 
                               payload: Dict[str, Any], 
                               db: Session) -> Optional[str]:
        """
        Handle recording status callback
        Returns recording URL if successful
        """
        try:
            call_sid = payload.get('CallSid')
            recording_sid = payload.get('RecordingSid')
            recording_url = payload.get('RecordingUrl')
            duration = payload.get('RecordingDuration', 0)

            call_record = db.query(CalledCall).filter(
                CalledCall.provider_call_sid == call_sid
            ).first()

            if call_record:
                call_record.provider_recording_sid = recording_sid
                call_record.recording_url = recording_url
                call_record.recording_duration = int(duration) if duration else None
                call_record.transcript_status = 'pending'  # Ready for transcription
                db.commit()

                logger.info(f"Recording saved for call {call_sid}: {recording_url}")
                return recording_url

            return None

        except Exception as e:
            logger.error(f"Recording webhook error: {str(e)}")
            return None

    def get_call_details(self, call_sid: str) -> Dict[str, Any]:
        """Fetch call details from provider"""
        try:
            call = self.client.calls(call_sid).fetch()
            return {
                'sid': call.sid,
                'status': call.status,
                'duration': call.duration,
                'price': call.price,
                'direction': call.direction
            }
        except Exception as e:
            logger.error(f"Failed to fetch call details: {str(e)}")
            return {}

    def _map_status(self, provider_status: str) -> CallStatus:
        """Map provider status to our enum"""
        status_map = {
            'queued': CallStatus.IN_PROGRESS,
            'ringing': CallStatus.IN_PROGRESS,
            'in-progress': CallStatus.ANSWERED,
            'completed': CallStatus.COMPLETED,
            'busy': CallStatus.BUSY,
            'failed': CallStatus.FAILED,
            'no-answer': CallStatus.MISSED,
            'canceled': CallStatus.REJECTED
        }
        return status_map.get(provider_status.lower(), CallStatus.IN_PROGRESS)

    def _get_base_url(self) -> str:
        """Get base URL for webhooks from config"""
        return os.getenv('BASE_URL', 'https://your-domain.com')

# Singleton instance
call_provider_service = CallProviderService()

"""
Transcription Service
Handles audio transcription using OpenAI Whisper or AssemblyAI
"""
import logging
import requests
import time
import os
from typing import Optional, Dict, Any
from sqlalchemy.orm import Session
from models import CalledCall
from config import openai_config, app_config

logger = logging.getLogger(__name__)

class TranscriptionService:
    """
    Service for transcribing call recordings
    Supports OpenAI Whisper API (primary) and AssemblyAI (fallback)
    """

    def __init__(self):
        self.openai_api_key = openai_config.api_key
        self.assemblyai_key = os.getenv('ASSEMBLYAI_API_KEY')

    def transcribe_call(self, call_id: int, db: Session) -> Dict[str, Any]:
        """
        Main method to transcribe a call recording

        Flow:
        1. Get recording URL from database
        2. Download audio
        3. Send to transcription API
        4. Store result in database
        """
        try:
            # Get call record
            call = db.query(CalledCall).filter(CalledCall.id == call_id).first()
            if not call:
                return {'success': False, 'error': 'Call not found'}

            if not call.recording_url:
                return {'success': False, 'error': 'No recording available'}

            # Update status
            call.transcript_status = 'processing'
            db.commit()

            # Attempt transcription with OpenAI first
            result = self._transcribe_with_openai(call.recording_url)

            if not result['success'] and self.assemblyai_key:
                # Fallback to AssemblyAI
                result = self._transcribe_with_assemblyai(call.recording_url)
                call.transcript_provider = 'assemblyai'
            else:
                call.transcript_provider = 'openai'

            if result['success']:
                call.transcript_text = result['text']
                call.transcript_status = 'completed'
                db.commit()

                logger.info(f"Transcription completed for call {call_id}")
                return {
                    'success': True,
                    'call_id': call_id,
                    'text': result['text'],
                    'provider': call.transcript_provider
                }
            else:
                call.transcript_status = 'failed'
                db.commit()
                return result

        except Exception as e:
            logger.error(f"Transcription error for call {call_id}: {str(e)}")
            call.transcript_status = 'failed'
            db.commit()
            return {'success': False, 'error': str(e)}

    def _transcribe_with_openai(self, audio_url: str) -> Dict[str, Any]:
        """
        Transcribe using OpenAI Whisper API
        Supports audio file URLs or local files
        """
        try:
            # Download audio from URL if needed
            if audio_url.startswith('http'):
                audio_data = self._download_audio(audio_url)
                if not audio_data:
                    return {'success': False, 'error': 'Failed to download audio'}
            else:
                with open(audio_url, 'rb') as f:
                    audio_data = f.read()

            # Call OpenAI Whisper API
            headers = {
                'Authorization': f'Bearer {self.openai_api_key}'
            }

            files = {
                'file': ('audio.mp3', audio_data, 'audio/mpeg'),
                'model': (None, 'whisper-1'),
                'language': (None, 'en'),
                'response_format': (None, 'text')
            }

            response = requests.post(
                'https://api.openai.com/v1/audio/transcriptions',
                headers=headers,
                files=files,
                timeout=120
            )

            if response.status_code == 200:
                return {
                    'success': True,
                    'text': response.text,
                    'provider': 'openai'
                }
            else:
                return {
                    'success': False,
                    'error': f'OpenAI API error: {response.status_code}',
                    'details': response.text
                }

        except Exception as e:
            logger.error(f"OpenAI transcription error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def _transcribe_with_assemblyai(self, audio_url: str) -> Dict[str, Any]:
        """
        Fallback transcription using AssemblyAI
        Better for dual-channel (stereo) recordings with speaker diarization
        """
        try:
            headers = {
                'authorization': self.assemblyai_key,
                'content-type': 'application/json'
            }

            # Submit transcription job
            json_data = {
                'audio_url': audio_url,
                'language_code': 'en_us',
                'speaker_labels': True,  # Enable speaker diarization
                'auto_highlights': True,
                'entity_detection': True
            }

            response = requests.post(
                'https://api.assemblyai.com/v2/transcript',
                headers=headers,
                json=json_data
            )

            if response.status_code != 200:
                return {'success': False, 'error': 'AssemblyAI submission failed'}

            transcript_id = response.json()['id']

            # Poll for completion
            max_attempts = 60  # 5 minutes
            for _ in range(max_attempts):
                time.sleep(5)

                polling_response = requests.get(
                    f'https://api.assemblyai.com/v2/transcript/{transcript_id}',
                    headers=headers
                )

                result = polling_response.json()
                status = result['status']

                if status == 'completed':
                    # Format with speaker labels
                    utterances = result.get('utterances', [])
                    formatted_text = self._format_with_speakers(utterances)

                    return {
                        'success': True,
                        'text': formatted_text,
                        'provider': 'assemblyai',
                        'highlights': result.get('auto_highlights_result', {}),
                        'entities': result.get('entities', [])
                    }
                elif status == 'error':
                    return {'success': False, 'error': result.get('error', 'Unknown error')}

            return {'success': False, 'error': 'Transcription timeout'}

        except Exception as e:
            logger.error(f"AssemblyAI transcription error: {str(e)}")
            return {'success': False, 'error': str(e)}

    def _download_audio(self, url: str) -> Optional[bytes]:
        """Download audio file from URL"""
        try:
            # Add .mp3 extension if Twilio recording
            if 'twilio.com' in url and not url.endswith('.mp3'):
                url += '.mp3'

            response = requests.get(url, timeout=60)
            if response.status_code == 200:
                return response.content
            return None
        except Exception as e:
            logger.error(f"Audio download error: {str(e)}")
            return None

    def _format_with_speakers(self, utterances: list) -> str:
        """Format transcript with speaker labels"""
        formatted = []
        for u in utterances:
            speaker = u.get('speaker', 'Unknown')
            text = u.get('text', '')
            formatted.append(f"Speaker {speaker}: {text}")
        return '
'.join(formatted)

    def batch_transcribe(self, call_ids: list, db: Session) -> Dict[str, Any]:
        """
        Transcribe multiple calls (for batch processing)
        """
        results = {
            'total': len(call_ids),
            'completed': 0,
            'failed': 0,
            'details': []
        }

        for call_id in call_ids:
            result = self.transcribe_call(call_id, db)
            if result['success']:
                results['completed'] += 1
            else:
                results['failed'] += 1
            results['details'].append(result)

        return results

# Singleton instance
transcription_service = TranscriptionService()

"""
Call System API
FastAPI endpoints for CRM integration
"""
from fastapi import FastAPI, Depends, HTTPException, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List, Optional, Dict, Any
from datetime import datetime
import logging

# Import services
from database import get_db, init_db
from services.call_provider import call_provider_service
from services.transcription import transcription_service
from services.ai_evaluation import ai_evaluation_service
from services.kpi import kpi_service
from services.automation import automation_service

# Import models for type hints
from models import CalledCall, CallDirection, CallStatus

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="LeadM8 Call System API",
    description="AI-powered call management and evaluation system",
    version="1.0.0"
)

# CORS middleware (adjust for your CRM domain)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Startup event
@app.on_event("startup")
async def startup_event():
    init_db()
    logger.info("Call System API started")

# ============================================================================
# 1. CALL INITIATION ENDPOINTS
# ============================================================================

@app.post("/api/calls/initiate")
async def initiate_call(
    lead_id: int,
    agent_id: int,
    phone_number: str,
    recording_enabled: bool = True,
    db: Session = Depends(get_db)
):
    """
    Initiate outbound call from CRM (Click-to-Call)

    - Creates call record in database
    - Initiates call via Twilio/CallGear
    - Returns call SID for tracking
    """
    try:
        # Create initial call record
        call_record = CalledCall(
            lead_id=lead_id,
            agent_id=agent_id,
            phone_number=phone_number,
            direction=CallDirection.OUTBOUND,
            status=CallStatus.IN_PROGRESS,
            started_at=datetime.utcnow()
        )
        db.add(call_record)
        db.commit()
        db.refresh(call_record)

        # Initiate call via provider
        result = call_provider_service.initiate_call(
            to_number=phone_number,
            lead_id=lead_id,
            agent_id=agent_id,
            recording_enabled=recording_enabled
        )

        if result['success']:
            # Update record with provider SID
            call_record.provider_call_sid = result['call_sid']
            db.commit()

            return {
                'success': True,
                'call_id': call_record.id,
                'call_sid': result['call_sid'],
                'status': result['status'],
                'message': 'Call initiated successfully'
            }
        else:
            # Mark as failed
            call_record.status = CallStatus.FAILED
            db.commit()

            raise HTTPException(status_code=400, detail=result.get('error', 'Call initiation failed'))

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Call initiation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/calls/{call_id}/status")
async def get_call_status(call_id: int, db: Session = Depends(get_db)):
    """Get current status of a call"""
    call = db.query(CalledCall).filter(CalledCall.id == call_id).first()
    if not call:
        raise HTTPException(status_code=404, detail="Call not found")

    return {
        'call_id': call.id,
        'status': call.status.value if call.status else None,
        'direction': call.direction.value if call.direction else None,
        'duration': call.duration_seconds,
        'recording_url': call.recording_url,
        'transcript_status': call.transcript_status,
        'ai_evaluation_status': call.ai_evaluation_status
    }

# ============================================================================
# 2. WEBHOOK ENDPOINTS (For Call Provider)
# ============================================================================

@app.post("/webhooks/call-status")
async def call_status_webhook(request: Request, db: Session = Depends(get_db)):
    """
    Receive call status updates from Twilio/CallGear
    Handles: initiated, ringing, answered, completed, failed, etc.
    """
    try:
        payload = await request.form()
        payload_dict = dict(payload)

        logger.info(f"Received call status webhook: {payload_dict.get('CallStatus')}")

        # Process webhook
        success = call_provider_service.handle_call_webhook(payload_dict, db)

        # If call completed, trigger automation workflow
        if success and payload_dict.get('CallStatus') == 'completed':
            call_sid = payload_dict.get('CallSid')
            call_record = db.query(CalledCall).filter(
                CalledCall.provider_call_sid == call_sid
            ).first()

            if call_record:
                # Trigger post-call automation
                automation_service.handle_call_completed(call_record.id, db)

        return {'success': success}

    except Exception as e:
        logger.error(f"Webhook processing error: {str(e)}")
        return {'success': False, 'error': str(e)}

@app.post("/webhooks/recording")
async def recording_webhook(request: Request, db: Session = Depends(get_db)):
    """
    Receive recording ready notification from Twilio/CallGear
    """
    try:
        payload = await request.form()
        payload_dict = dict(payload)

        logger.info(f"Received recording webhook for call {payload_dict.get('CallSid')}")

        recording_url = call_provider_service.handle_recording_webhook(payload_dict, db)

        if recording_url:
            return {'success': True, 'recording_url': recording_url}
        else:
            return {'success': False, 'error': 'Failed to process recording'}

    except Exception as e:
        logger.error(f"Recording webhook error: {str(e)}")
        return {'success': False, 'error': str(e)}

@app.post("/twiml/connect-agent")
async def connect_agent(agent_id: int, request: Request):
    """
    Generate TwiML for connecting agent to call
    Called when call is answered
    """
    # In production, fetch agent's phone/endpoint from database
    # For now, return simple connect
    twiml = call_provider_service.generate_twiml_for_agent(
        agent_phone=f"client:{agent_id}",  # Or actual phone number
        lead_id=0  # Will be populated from context
    )

    from fastapi.responses import Response
    return Response(content=twiml, media_type="application/xml")

# ============================================================================
# 3. TRANSCRIPTION ENDPOINTS
# ============================================================================

@app.post("/api/calls/{call_id}/transcribe")
async def transcribe_call(call_id: int, db: Session = Depends(get_db)):
    """
    Manually trigger transcription for a call
    (Usually auto-triggered by webhook)
    """
    result = transcription_service.transcribe_call(call_id, db)

    if result['success']:
        return result
    else:
        raise HTTPException(status_code=400, detail=result.get('error', 'Transcription failed'))

@app.get("/api/calls/{call_id}/transcript")
async def get_transcript(call_id: int, db: Session = Depends(get_db)):
    """Get transcript text for a call"""
    call = db.query(CalledCall).filter(CalledCall.id == call_id).first()
    if not call:
        raise HTTPException(status_code=404, detail="Call not found")

    return {
        'call_id': call_id,
        'transcript_status': call.transcript_status,
        'transcript_text': call.transcript_text,
        'provider': call.transcript_provider
    }

# ============================================================================
# 4. AI EVALUATION ENDPOINTS
# ============================================================================

@app.post("/api/calls/{call_id}/evaluate")
async def evaluate_call(call_id: int, db: Session = Depends(get_db)):
    """
    Trigger AI evaluation for a call
    Requires transcript to be completed first
    """
    result = ai_evaluation_service.evaluate_call(call_id, db)

    if result['success']:
        return result
    else:
        raise HTTPException(status_code=400, detail=result.get('error', 'Evaluation failed'))

@app.get("/api/calls/{call_id}/evaluation")
async def get_evaluation(call_id: int, db: Session = Depends(get_db)):
    """Get AI evaluation results for a call"""
    result = ai_evaluation_service.get_evaluation_summary(call_id, db)

    if result['success']:
        return result
    else:
        raise HTTPException(status_code=404, detail=result.get('error', 'Evaluation not found'))

@app.get("/api/calls/{call_id}/full-analysis")
async def get_full_analysis(call_id: int, db: Session = Depends(get_db)):
    """Get complete AI analysis including strengths, weaknesses, recommendations"""
    call = db.query(CalledCall).filter(CalledCall.id == call_id).first()
    if not call:
        raise HTTPException(status_code=404, detail="Call not found")

    if call.ai_evaluation_status != 'completed':
        raise HTTPException(status_code=400, detail="AI evaluation not completed")

    return {
        'call_id': call_id,
        'scores': {
            'overall': call.ai_overall_score,
            'confidence': call.ai_confidence_score,
            'lead_intent': call.ai_lead_intent_score,
            'closing_probability': call.ai_closing_probability
        },
        'strengths': call.ai_strengths,
        'weaknesses': call.ai_weaknesses,
        'full_analysis': call.ai_full_analysis
    }

# ============================================================================
# 5. KPI & REPORTING ENDPOINTS
# ============================================================================

@app.get("/api/agents/{agent_id}/kpi/weekly")
async def get_weekly_kpi(agent_id: int, db: Session = Depends(get_db)):
    """Get weekly KPIs for an agent"""
    result = kpi_service.calculate_weekly_kpis(agent_id, db)

    if result['success']:
        return result
    else:
        raise HTTPException(status_code=400, detail=result.get('error', 'KPI calculation failed'))

@app.get("/api/agents/{agent_id}/kpi/monthly")
async def get_monthly_kpi(agent_id: int, db: Session = Depends(get_db)):
    """Get monthly KPIs for an agent"""
    result = kpi_service.calculate_monthly_kpis(agent_id, db)

    if result['success']:
        return result
    else:
        raise HTTPException(status_code=400, detail=result.get('error', 'KPI calculation failed'))

@app.get("/api/agents/rankings")
async def get_agent_rankings(
    period_type: str = "monthly",
    db: Session = Depends(get_db)
):
    """Get agent rankings for a period"""
    result = kpi_service.get_agent_ranking(db, period_type)

    if result['success']:
        return result
    else:
        raise HTTPException(status_code=400, detail=result.get('error', 'Ranking failed'))

@app.get("/api/agents/{agent_id}/trends")
async def get_agent_trends(
    agent_id: int,
    weeks: int = 4,
    db: Session = Depends(get_db)
):
    """Get performance trends over time"""
    result = kpi_service.get_performance_trends(agent_id, weeks, db)

    if result['success']:
        return result
    else:
        raise HTTPException(status_code=400, detail=result.get('error', 'Trend analysis failed'))

@app.get("/api/agents/{agent_id}/report")
async def export_report(
    agent_id: int,
    period_type: str,
    format: str = "json",  # or "csv"
    db: Session = Depends(get_db)
):
    """Export KPI report"""
    from datetime import datetime

    # Determine period start
    if period_type == "weekly":
        period_start = datetime.utcnow() - timedelta(days=datetime.utcnow().weekday())
    else:
        period_start = datetime.utcnow().replace(day=1)

    result = kpi_service.export_report(agent_id, period_type, period_start, format, db)

    if result['success']:
        if format.lower() == "csv":
            from fastapi.responses import PlainTextResponse
            return PlainTextResponse(content=result['data'], media_type="text/csv")
        return result
    else:
        raise HTTPException(status_code=400, detail=result.get('error', 'Export failed'))

# ============================================================================
# 6. AUTOMATION & WORKFLOW ENDPOINTS
# ============================================================================

@app.get("/api/calls/{call_id}/workflow-status")
async def get_workflow_status(call_id: int, db: Session = Depends(get_db)):
    """Get current automation workflow status for a call"""
    return automation_service.get_workflow_status(call_id, db)

@app.post("/api/calls/{call_id}/retry-evaluation")
async def retry_evaluation(call_id: int, db: Session = Depends(get_db)):
    """Manually retry AI evaluation for a call"""
    result = automation_service.manual_trigger_evaluation(call_id, db)

    if result['success']:
        return result
    else:
        raise HTTPException(status_code=400, detail=result.get('error', 'Retry failed'))

# ============================================================================
# 7. CRM INTEGRATION ENDPOINTS (Called Calls Module)
# ============================================================================

@app.get("/api/called-calls")
async def list_called_calls(
    lead_id: Optional[int] = None,
    agent_id: Optional[int] = None,
    limit: int = 50,
    offset: int = 0,
    db: Session = Depends(get_db)
):
    """
    List all called calls (for CRM Called Calls module)
    Supports filtering by lead_id or agent_id
    """
    query = db.query(CalledCall)

    if lead_id:
        query = query.filter(CalledCall.lead_id == lead_id)
    if agent_id:
        query = query.filter(CalledCall.agent_id == agent_id)

    total = query.count()
    calls = query.order_by(CalledCall.call_date.desc()).offset(offset).limit(limit).all()

    return {
        'total': total,
        'limit': limit,
        'offset': offset,
        'calls': [
            {
                'id': c.id,
                'lead_id': c.lead_id,
                'agent_id': c.agent_id,
                'phone_number': c.phone_number,
                'direction': c.direction.value if c.direction else None,
                'status': c.status.value if c.status else None,
                'call_date': c.call_date.isoformat() if c.call_date else None,
                'duration_seconds': c.duration_seconds,
                'recording_url': c.recording_url,
                'transcript_status': c.transcript_status,
                'ai_overall_score': c.ai_overall_score,
                'ai_evaluation_status': c.ai_evaluation_status
            }
            for c in calls
        ]
    }

@app.get("/api/called-calls/{call_id}")
async def get_call_detail(call_id: int, db: Session = Depends(get_db)):
    """Get full details of a specific call"""
    call = db.query(CalledCall).filter(CalledCall.id == call_id).first()
    if not call:
        raise HTTPException(status_code=404, detail="Call not found")

    return {
        'id': call.id,
        'lead_id': call.lead_id,
        'agent_id': call.agent_id,
        'phone_number': call.phone_number,
        'direction': call.direction.value if call.direction else None,
        'status': call.status.value if call.status else None,
        'call_date': call.call_date.isoformat() if call.call_date else None,
        'started_at': call.started_at.isoformat() if call.started_at else None,
        'ended_at': call.ended_at.isoformat() if call.ended_at else None,
        'duration_seconds': call.duration_seconds,
        'provider_call_sid': call.provider_call_sid,
        'recording_url': call.recording_url,
        'recording_duration': call.recording_duration,
        'transcript_text': call.transcript_text,
        'transcript_status': call.transcript_status,
        'transcript_provider': call.transcript_provider,
        'ai_evaluation_status': call.ai_evaluation_status,
        'ai_overall_score': call.ai_overall_score,
        'ai_confidence_score': call.ai_confidence_score,
        'ai_lead_intent_score': call.ai_lead_intent_score,
        'ai_closing_probability': call.ai_closing_probability,
        'ai_strengths': call.ai_strengths,
        'ai_weaknesses': call.ai_weaknesses,
        'ai_full_analysis': call.ai_full_analysis
    }

# ============================================================================
# 8. HEALTH CHECK
# ============================================================================

@app.get("/health")
async def health_check():
    """System health check"""
    return {
        'status': 'healthy',
        'service': 'LeadM8 Call System',
        'timestamp': datetime.utcnow().isoformat()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

"""
Database Models for Call System
Extends existing CRM without modifying existing tables
"""
from sqlalchemy import Column, Integer, String, DateTime, Float, Text, Boolean, ForeignKey, Enum, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import enum

Base = declarative_base()

class CallDirection(enum.Enum):
    INBOUND = "inbound"
    OUTBOUND = "outbound"

class CallStatus(enum.Enum):
    ANSWERED = "answered"
    MISSED = "missed"
    REJECTED = "rejected"
    BUSY = "busy"
    FAILED = "failed"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"

class CalledCall(Base):
    """
    Called Calls Module - Core table for call logging
    Maps to CRM 'called_calls' table
    """
    __tablename__ = 'called_calls'

    id = Column(Integer, primary_key=True, index=True)
    lead_id = Column(Integer, ForeignKey('leads.id'), nullable=False, index=True)
    agent_id = Column(Integer, ForeignKey('users.id'), nullable=False, index=True)

    # Call details
    phone_number = Column(String(20), nullable=False)
    direction = Column(Enum(CallDirection), nullable=False)
    status = Column(Enum(CallStatus), nullable=False, default=CallStatus.IN_PROGRESS)

    # Timing
    call_date = Column(DateTime, default=datetime.utcnow)
    started_at = Column(DateTime)
    ended_at = Column(DateTime)
    duration_seconds = Column(Integer, default=0)

    # External IDs
    provider_call_sid = Column(String(50), unique=True, index=True)  # Twilio/CallGear call ID
    provider_recording_sid = Column(String(50), unique=True, index=True)

    # Media
    recording_url = Column(Text)
    recording_duration = Column(Integer)

    # Transcription
    transcript_text = Column(Text)
    transcript_status = Column(String(20), default='pending')  # pending, processing, completed, failed
    transcript_provider = Column(String(20))  # openai, assemblyai, etc.

    # AI Evaluation
    ai_evaluation_status = Column(String(20), default='pending')  # pending, completed, failed
    ai_overall_score = Column(Float)
    ai_confidence_score = Column(Float)
    ai_closing_probability = Column(Float)
    ai_lead_intent_score = Column(Float)

    # Stored as JSON for flexibility
    ai_strengths = Column(JSON, default=list)
    ai_weaknesses = Column(JSON, default=list)
    ai_full_analysis = Column(JSON)

    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships (optional, for ORM convenience)
    # lead = relationship("Lead", back_populates="calls")
    # agent = relationship("User", back_populates="calls")

class CallKPI(Base):
    """
    KPI Metrics - Weekly and Monthly aggregation
    """
    __tablename__ = 'call_kpis'

    id = Column(Integer, primary_key=True)
    agent_id = Column(Integer, ForeignKey('users.id'), nullable=False, index=True)

    # Period
    period_type = Column(String(10), nullable=False)  # 'weekly' or 'monthly'
    period_start = Column(DateTime, nullable=False)
    period_end = Column(DateTime, nullable=False)

    # Volume metrics
    total_calls = Column(Integer, default=0)
    inbound_calls = Column(Integer, default=0)
    outbound_calls = Column(Integer, default=0)
    answered_calls = Column(Integer, default=0)
    missed_calls = Column(Integer, default=0)

    # Quality metrics
    total_duration_seconds = Column(Integer, default=0)
    avg_duration_seconds = Column(Float, default=0.0)
    avg_ai_score = Column(Float, default=0.0)

    # Performance metrics
    answer_rate = Column(Float, default=0.0)  # percentage
    high_intent_calls = Column(Integer, default=0)  # ai_lead_intent_score > 70
    weak_calls = Column(Integer, default=0)  # ai_overall_score < 50

    # Conversion (if CRM provides lead status updates)
    leads_converted = Column(Integer, default=0)
    conversion_rate = Column(Float, default=0.0)

    # AI Insights aggregation
    common_strengths = Column(JSON, default=list)
    common_weaknesses = Column(JSON, default=list)
    improvement_suggestions = Column(Text)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        # Unique constraint to prevent duplicate KPIs for same agent/period
        {'sqlite_autoincrement': True},
    )

class CallWebhookLog(Base):
    """
    Audit log for all webhooks received
    """
    __tablename__ = 'call_webhook_logs'

    id = Column(Integer, primary_key=True)
    provider = Column(String(20), nullable=False)  # twilio, callgear
    event_type = Column(String(50), nullable=False)  # call.initiated, call.completed, etc.
    payload = Column(JSON, nullable=False)
    processed = Column(Boolean, default=False)
    error_message = Column(Text)
    received_at = Column(DateTime, default=datetime.utcnow)
    processed_at = Column(DateTime)

class AIEvaluationPrompt(Base):
    """
    Store different prompt templates for AI evaluation
    """
    __tablename__ = 'ai_evaluation_prompts'

    id = Column(Integer, primary_key=True)
    name = Column(String(50), unique=True, nullable=False)
    version = Column(Integer, default=1)
    prompt_template = Column(Text, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

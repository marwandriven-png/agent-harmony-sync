"""
Call System Configuration
Environment variables and system settings
"""
import os
from dataclasses import dataclass
from typing import Optional

@dataclass
class CallProviderConfig:
    """Call provider configuration (Twilio/CallGear)"""
    account_sid: str = os.getenv('CALL_PROVIDER_ACCOUNT_SID', 'your_account_sid')
    auth_token: str = os.getenv('CALL_PROVIDER_AUTH_TOKEN', 'your_auth_token')
    api_key: str = os.getenv('CALL_PROVIDER_API_KEY', 'your_api_key')
    webhook_secret: str = os.getenv('CALL_PROVIDER_WEBHOOK_SECRET', 'your_webhook_secret')
    from_number: str = os.getenv('CALL_PROVIDER_FROM_NUMBER', '+1234567890')

@dataclass
class OpenAIConfig:
    """OpenAI API configuration"""
    api_key: str = os.getenv('OPENAI_API_KEY', 'your_openai_api_key')
    model: str = os.getenv('OPENAI_MODEL', 'gpt-4o')
    max_tokens: int = 2000
    temperature: float = 0.3  # Lower for consistent evaluation

@dataclass
class DatabaseConfig:
    """CRM Database configuration"""
    host: str = os.getenv('DB_HOST', 'localhost')
    port: int = int(os.getenv('DB_PORT', 5432))
    name: str = os.getenv('DB_NAME', 'crm_db')
    user: str = os.getenv('DB_USER', 'crm_user')
    password: str = os.getenv('DB_PASSWORD', 'crm_password')

@dataclass
class AppConfig:
    """Application configuration"""
    debug: bool = os.getenv('DEBUG', 'false').lower() == 'true'
    log_level: str = os.getenv('LOG_LEVEL', 'INFO')
    max_retries: int = 3
    retry_delay: int = 5  # seconds

    # Call system settings
    default_call_timeout: int = 30  # seconds
    recording_format: str = 'mp3'
    transcription_language: str = 'en'

    # Rate limiting
    max_calls_per_minute: int = 10
    max_ai_evaluations_per_hour: int = 100

# Global instances
call_provider_config = CallProviderConfig()
openai_config = OpenAIConfig()
db_config = DatabaseConfig()
app_config = AppConfig()

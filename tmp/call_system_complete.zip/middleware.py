"""
Security Middleware
Handles Twilio webhook validation and JWT authentication
"""
import os
import hmac
import hashlib
import base64
import logging
from typing import Optional
from fastapi import Request, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from twilio.request_validator import RequestValidator
import jwt
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

# JWT Configuration
SECRET_KEY = os.getenv('SECRET_KEY', 'your-secret-key-change-in-production')
ALGORITHM = 'HS256'
ACCESS_TOKEN_EXPIRE_DAYS = 7

security = HTTPBearer(auto_error=False)

class SecurityMiddleware:
    """
    Handles all security validations:
    1. Twilio webhook signature validation
    2. JWT token authentication for API endpoints
    """

    def __init__(self):
        self.twilio_auth_token = os.getenv('CALL_PROVIDER_AUTH_TOKEN')
        self.twilio_validator = RequestValidator(self.twilio_auth_token) if self.twilio_auth_token else None

    async def validate_twilio_webhook(self, request: Request) -> bool:
        """
        Validate Twilio webhook signature
        Must be called for all Twilio webhook endpoints
        """
        if not self.twilio_validator:
            logger.warning('Twilio validator not configured, skipping validation')
            return True

        try:
            # Get signature from header
            signature = request.headers.get('X-Twilio-Signature', '')
            if not signature:
                logger.error('Missing X-Twilio-Signature header')
                return False

            # Get URL (must be exact URL Twilio used)
            url = str(request.url)

            # Get form parameters
            form_data = await request.form()
            params = dict(form_data)

            # Validate
            is_valid = self.twilio_validator.validate(url, params, signature)

            if not is_valid:
                logger.error(f'Invalid Twilio signature for URL: {url}')
                return False

            logger.info('Twilio webhook signature validated successfully')
            return True

        except Exception as e:
            logger.error(f'Webhook validation error: {str(e)}')
            return False

    def create_access_token(self, data: dict, expires_delta: Optional[timedelta] = None) -> str:
        """
        Create JWT access token
        """
        to_encode = data.copy()

        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + timedelta(days=ACCESS_TOKEN_EXPIRE_DAYS)

        to_encode.update({'exp': expire, 'iat': datetime.utcnow()})

        encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
        return encoded_jwt

    def verify_access_token(self, token: str) -> Optional[dict]:
        """
        Verify and decode JWT token
        Returns payload if valid, None if invalid
        """
        try:
            payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
            return payload
        except jwt.ExpiredSignatureError:
            logger.warning('Token expired')
            return None
        except jwt.InvalidTokenError as e:
            logger.warning(f'Invalid token: {str(e)}')
            return None

    async def jwt_auth(self, credentials: HTTPAuthorizationCredentials = security) -> dict:
        """
        FastAPI dependency for JWT authentication
        Usage: async def endpoint(auth: dict = Depends(security_middleware.jwt_auth))
        """
        if not credentials:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail='Authorization header missing',
                headers={'WWW-Authenticate': 'Bearer'}
            )

        token = credentials.credentials
        payload = self.verify_access_token(token)

        if not payload:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail='Invalid or expired token',
                headers={'WWW-Authenticate': 'Bearer'}
            )

        return payload

# Singleton instance
security_middleware = SecurityMiddleware()

# Convenience function for route protection
def require_auth():
    """Dependency for protected routes"""
    return security_middleware.jwt_auth

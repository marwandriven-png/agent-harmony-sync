# LeadM8 Call System - Deployment Guide

## 🚀 Production Deployment Options

### Option 1: Docker Deployment (Recommended)

```bash
# Build image
docker build -t leadm8-call-system .

# Run container
docker run -d \
  --name leadm8-calls \
  -p 8000:8000 \
  --env-file .env \
  -v /host/path/recordings:/app/recordings \
  leadm8-call-system
```

### Option 2: Cloud Deployment (AWS/GCP/Azure)

**AWS ECS/Fargate:**
```bash
# Push to ECR
aws ecr get-login-password | docker login --username AWS --password-stdin [account].dkr.ecr.[region].amazonaws.com
docker tag leadm8-call-system:latest [account].dkr.ecr.[region].amazonaws.com/leadm8-calls:latest
docker push [account].dkr.ecr.[region].amazonaws.com/leadm8-calls:latest

# Deploy to ECS
aws ecs update-service --cluster leadm8-cluster --service call-system --force-new-deployment
```

**Google Cloud Run:**
```bash
gcloud run deploy leadm8-calls \
  --image gcr.io/PROJECT-ID/leadm8-calls \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --set-env-vars "DB_HOST=...,OPENAI_API_KEY=..."
```

### Option 3: VPS/Server Deployment

```bash
# System dependencies
sudo apt update
sudo apt install -y python3-pip python3-venv postgresql-client nginx

# Setup app
git clone <repo-url>
cd call_system
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Environment setup
cp .env.example .env
nano .env  # Edit with your credentials

# Database setup
python -c "from database import init_db; init_db()"

# Systemd service
sudo nano /etc/systemd/system/leadm8-calls.service
```

**Systemd Service File:**
```ini
[Unit]
Description=LeadM8 Call System
After=network.target

[Service]
Type=simple
User=appuser
WorkingDirectory=/opt/call_system
Environment=PATH=/opt/call_system/venv/bin
ExecStart=/opt/call_system/venv/bin/uvicorn api:app --host 0.0.0.0 --port 8000 --workers 4
Restart=always

[Install]
WantedBy=multi-user.target
```

---

## 🔧 Post-Deployment Configuration

### 1. Twilio Webhook Setup

1. Login to Twilio Console
2. Go to Phone Numbers → Manage → Active Numbers
3. Select your number
4. Configure webhooks:
   - **Voice & Fax**: 
     - A call comes in: Webhook → `https://your-domain.com/twiml/connect-agent`
     - Call status changes: Webhook → `https://your-domain.com/webhooks/call-status`
   - **Recording**: 
     - Recording status callback: `https://your-domain.com/webhooks/recording`

### 2. CRM Integration

Add to your CRM's base template:

```html
<!-- In <head> or before closing </body> -->
<script src="https://your-domain.com/static/leadm8-crm-integration.js"></script>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    LeadM8CallSystem.init({
      apiBaseUrl: 'https://your-domain.com',
      agentId: {{ current_user.id }},  // Your CRM's user ID
      authToken: '{{ jwt_token }}'     // Your CRM's auth mechanism
    });
  });
</script>
```

### 3. Database Migration (if existing CRM)

If adding to existing CRM database:

```sql
-- Run these SQL commands to add tables
-- (SQLAlchemy will create them automatically on first run)

-- Or manually create:
CREATE TABLE called_calls (...);
CREATE TABLE call_kpis (...);
CREATE TABLE call_webhook_logs (...);
CREATE TABLE ai_evaluation_prompts (...);
```

---

## 🔒 SSL/HTTPS Setup

### Using Let's Encrypt + Nginx

```nginx
# /etc/nginx/sites-available/leadm8-calls
server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /etc/letsencrypt/live/your-domain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain.com/privkey.pem;

    location / {
        proxy_pass http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
# Enable site
sudo ln -s /etc/nginx/sites-available/leadm8-calls /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx

# Get SSL certificate
sudo certbot --nginx -d your-domain.com
```

---

## 📊 Monitoring Setup

### Health Checks

```bash
# Add to monitoring system (e.g., UptimeRobot, Pingdom)
# Check every 5 minutes:
GET https://your-domain.com/health

# Expected response:
{"status": "healthy", "service": "LeadM8 Call System", "timestamp": "..."}
```

### Logging

```python
# Structured logging is configured in the app
# Logs are written to stdout (captured by Docker/systemd)

# View logs:
docker logs -f leadm8-calls  # Docker
journalctl -u leadm8-calls -f  # Systemd
```

### Metrics to Monitor

1. **API Response Times**: < 500ms for call initiation
2. **Webhook Delivery**: 100% success rate
3. **Transcription Queue**: < 50 pending jobs
4. **AI Evaluation Queue**: < 20 pending jobs
5. **Database Connections**: < 80% pool utilization
6. **Error Rate**: < 1% of requests

---

## 🔄 Backup & Recovery

### Database Backup

```bash
# Daily backup script
#!/bin/bash
BACKUP_DIR="/backups/postgres"
DATE=$(date +%Y%m%d_%H%M%S)

pg_dump -h localhost -U crm_user crm_db > "$BACKUP_DIR/crm_backup_$DATE.sql"

# Keep only last 30 days
find $BACKUP_DIR -type f -mtime +30 -delete
```

### Recording Files Backup

```bash
# Sync to S3 (if storing recordings locally)
aws s3 sync /app/recordings/ s3://leadm8-recordings/ --delete
```

### Disaster Recovery

1. **Database Restore**:
   ```bash
   psql -h localhost -U crm_user crm_db < crm_backup_YYYYMMDD.sql
   ```

2. **Service Restart**:
   ```bash
   docker-compose restart  # or
   sudo systemctl restart leadm8-calls
   ```

---

## 🧪 Testing Checklist

Before going live:

- [ ] Call initiation works from CRM
- [ ] Recording is saved and accessible
- [ ] Transcription completes within 2 minutes
- [ ] AI evaluation generates scores
- [ ] Webhooks receive and process correctly
- [ ] KPI calculations run on schedule
- [ ] Reports export correctly
- [ ] SSL certificate valid
- [ ] Health check endpoint responds
- [ ] Error handling works (invalid numbers, etc.)
- [ ] Rate limiting prevents abuse
- [ ] Authentication protects endpoints

---

## 💰 Cost Estimation (Monthly)

**Small Team (5 agents, ~500 calls/month):**
- Twilio: ~$75 (voice + recording)
- OpenAI (Whisper): ~$25
- OpenAI (GPT-4 eval): ~$50
- Server (small VPS): ~$20
- **Total: ~$170/month**

**Medium Team (20 agents, ~2000 calls/month):**
- Twilio: ~$300
- OpenAI (Whisper): ~$100
- OpenAI (GPT-4 eval): ~$200
- Server (medium VPS): ~$50
- **Total: ~$650/month**

**Cost Optimization Tips:**
- Use AssemblyAI for transcription (50% cheaper)
- Use GPT-4o-mini for evaluation (90% cheaper)
- Archive old recordings to cold storage

---

## 🆘 Emergency Contacts

- **Twilio Support**: https://support.twilio.com
- **OpenAI Status**: https://status.openai.com
- **Your Hosting Provider**: [Add contact]
- **Internal DevOps**: [Add contact]

---

## 📝 Change Log

**v1.0.0** (Initial Release)
- Click-to-call from CRM
- Automatic recording and transcription
- AI evaluation with GPT-4
- Weekly/monthly KPIs
- Full API documentation

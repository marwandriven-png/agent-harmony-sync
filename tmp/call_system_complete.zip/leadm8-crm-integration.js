/**
 * LeadM8 Call System - CRM Integration
 * 
 * This JavaScript file provides click-to-call functionality
 * that integrates with your existing CRM without modifying its UI.
 * 
 * Usage: Include this file in your CRM and initialize with:
 * LeadM8CallSystem.init({
 *   apiBaseUrl: 'https://your-api-domain.com',
 *   agentId: 123,
 *   authToken: 'your-jwt-token'
 * });
 */

(function(window) {
    'use strict';

    const LeadM8CallSystem = {
        config: {
            apiBaseUrl: '',
            agentId: null,
            authToken: null,
            twilioToken: null,
            device: null
        },

        /**
         * Initialize the call system
         */
        init: function(options) {
            this.config.apiBaseUrl = options.apiBaseUrl || '';
            this.config.agentId = options.agentId || null;
            this.config.authToken = options.authToken || null;

            console.log('LeadM8 Call System initialized');
            this.setupClickToCallButtons();
            this.initializeTwilioDevice();
        },

        /**
         * Setup click-to-call buttons in CRM
         * Looks for elements with data-call-phone attribute
         */
        setupClickToCallButtons: function() {
            const self = this;

            // Find all phone number elements that should have call buttons
            // Assumes CRM has elements like: <span class="phone-number" data-phone="+1234567890">...</span>
            const phoneElements = document.querySelectorAll('[data-phone], .phone-number, [data-call-phone]');

            phoneElements.forEach(function(elem) {
                // Avoid duplicate buttons
                if (elem.querySelector('.leadm8-call-btn')) return;

                const phone = elem.getAttribute('data-phone') || 
                             elem.getAttribute('data-call-phone') || 
                             elem.textContent.trim();

                const leadId = elem.getAttribute('data-lead-id') || 
                              elem.closest('[data-lead-id]')?.getAttribute('data-lead-id');

                // Create call button
                const callBtn = document.createElement('button');
                callBtn.className = 'leadm8-call-btn';
                callBtn.innerHTML = '📞'; // Phone emoji or use icon font
                callBtn.title = 'Click to call ' + phone;
                callBtn.style.cssText = `
                    margin-left: 8px;
                    padding: 2px 6px;
                    cursor: pointer;
                    background: #10b981;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    font-size: 12px;
                    line-height: 1;
                `;

                callBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    self.initiateCall(phone, leadId);
                });

                elem.appendChild(callBtn);
            });

            console.log('Setup ' + phoneElements.length + ' click-to-call buttons');
        },

        /**
         * Initialize Twilio Device for browser calling (optional)
         */
        initializeTwilioDevice: function() {
            // Only initialize if Twilio SDK is loaded
            if (typeof Twilio === 'undefined') {
                console.log('Twilio SDK not loaded, skipping device initialization');
                return;
            }

            const self = this;

            // Fetch capability token from backend
            fetch(this.config.apiBaseUrl + '/api/twilio/token?agent_id=' + this.config.agentId, {
                headers: { 'Authorization': 'Bearer ' + this.config.authToken }
            })
            .then(res => res.json())
            .then(data => {
                if (data.token) {
                    self.config.twilioToken = data.token;
                    self.config.device = new Twilio.Device(data.token, {
                        codecPreferences: ['opus', 'pcmu'],
                        fakeLocalDTMF: true,
                        enableRingingState: true
                    });

                    self.config.device.on('ready', function() {
                        console.log('Twilio device ready');
                    });

                    self.config.device.on('error', function(error) {
                        console.error('Twilio device error:', error);
                    });

                    self.config.device.on('connect', function(conn) {
                        console.log('Call connected');
                        self.showCallStatus('connected', conn.parameters.From);
                    });

                    self.config.device.on('disconnect', function() {
                        console.log('Call disconnected');
                        self.showCallStatus('disconnected');
                    });
                }
            })
            .catch(err => console.error('Failed to initialize Twilio device:', err));
        },

        /**
         * Initiate a call
         */
        initiateCall: function(phoneNumber, leadId) {
            const self = this;

            // Show calling UI
            this.showCallStatus('calling', phoneNumber);

            // Call backend API
            fetch(this.config.apiBaseUrl + '/api/calls/initiate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + this.config.authToken
                },
                body: JSON.stringify({
                    lead_id: parseInt(leadId) || 0,
                    agent_id: this.config.agentId,
                    phone_number: phoneNumber,
                    recording_enabled: true
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    self.showCallStatus('initiated', phoneNumber, data.call_id);

                    // Poll for status updates
                    self.pollCallStatus(data.call_id);
                } else {
                    self.showCallStatus('failed', phoneNumber, null, data.error);
                }
            })
            .catch(error => {
                console.error('Call initiation error:', error);
                self.showCallStatus('failed', phoneNumber, null, error.message);
            });
        },

        /**
         * Poll call status for updates
         */
        pollCallStatus: function(callId) {
            const self = this;
            let pollCount = 0;
            const maxPolls = 60; // 5 minutes at 5-second intervals

            const poll = function() {
                if (pollCount >= maxPolls) return;
                pollCount++;

                fetch(self.config.apiBaseUrl + '/api/calls/' + callId + '/status', {
                    headers: { 'Authorization': 'Bearer ' + self.config.authToken }
                })
                .then(res => res.json())
                .then(data => {
                    self.updateCallStatusUI(data);

                    // Continue polling if call is active
                    if (['in_progress', 'ringing', 'answered'].includes(data.status)) {
                        setTimeout(poll, 5000);
                    }
                })
                .catch(err => console.error('Status poll error:', err));
            };

            poll();
        },

        /**
         * Show call status overlay
         */
        showCallStatus: function(status, phoneNumber, callId, error) {
            // Remove existing overlay
            const existing = document.getElementById('leadm8-call-overlay');
            if (existing) existing.remove();

            const overlay = document.createElement('div');
            overlay.id = 'leadm8-call-overlay';
            overlay.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                border: 2px solid #10b981;
                border-radius: 8px;
                padding: 16px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                z-index: 9999;
                font-family: system-ui, -apple-system, sans-serif;
                min-width: 250px;
            `;

            let content = '';
            switch(status) {
                case 'calling':
                    content = `
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <div style="width: 40px; height: 40px; border: 3px solid #10b981; border-top-color: transparent; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                            <div>
                                <div style="font-weight: bold; color: #374151;">Calling...</div>
                                <div style="color: #6b7280; font-size: 14px;">${phoneNumber}</div>
                            </div>
                        </div>
                        <style>@keyframes spin { to { transform: rotate(360deg); } }</style>
                    `;
                    break;
                case 'initiated':
                    content = `
                        <div style="color: #059669; font-weight: bold;">✓ Call Initiated</div>
                        <div style="color: #6b7280; font-size: 14px; margin-top: 4px;">${phoneNumber}</div>
                        <div style="color: #9ca3af; font-size: 12px; margin-top: 8px;">Call ID: ${callId}</div>
                    `;
                    break;
                case 'failed':
                    content = `
                        <div style="color: #dc2626; font-weight: bold;">✗ Call Failed</div>
                        <div style="color: #6b7280; font-size: 14px; margin-top: 4px;">${error || 'Unknown error'}</div>
                    `;
                    break;
            }

            overlay.innerHTML = content;
            document.body.appendChild(overlay);

            // Auto-remove after 10 seconds for non-active states
            if (['failed', 'completed'].includes(status)) {
                setTimeout(() => overlay.remove(), 10000);
            }
        },

        /**
         * Update call status UI
         */
        updateCallStatusUI: function(data) {
            // Update existing overlay or create new one
            const overlay = document.getElementById('leadm8-call-overlay');
            if (!overlay) return;

            const statusText = {
                'in_progress': 'Connecting...',
                'ringing': 'Ringing...',
                'answered': 'In Progress',
                'completed': 'Call Completed',
                'failed': 'Call Failed',
                'missed': 'Missed Call'
            }[data.status] || data.status;

            const color = data.status === 'completed' ? '#059669' : 
                         data.status === 'failed' ? '#dc2626' : '#10b981';

            overlay.innerHTML = `
                <div style="color: ${color}; font-weight: bold;">${statusText}</div>
                <div style="color: #6b7280; font-size: 14px; margin-top: 4px;">
                    Duration: ${data.duration || 0}s
                </div>
                ${data.recording_url ? '<div style="color: #10b981; font-size: 12px; margin-top: 8px;">✓ Recording Available</div>' : ''}
            `;
        },

        /**
         * Fetch called calls for a lead (for CRM display)
         */
        fetchCalledCalls: function(leadId, callback) {
            fetch(this.config.apiBaseUrl + '/api/called-calls?lead_id=' + leadId, {
                headers: { 'Authorization': 'Bearer ' + this.config.authToken }
            })
            .then(res => res.json())
            .then(data => callback(null, data))
            .catch(err => callback(err));
        },

        /**
         * Render called calls list in CRM
         */
        renderCalledCalls: function(containerId, leadId) {
            const self = this;
            const container = document.getElementById(containerId);
            if (!container) return;

            this.fetchCalledCalls(leadId, function(err, data) {
                if (err || !data.calls) {
                    container.innerHTML = '<div style="color: #dc2626;">Failed to load calls</div>';
                    return;
                }

                let html = '<div style="margin-top: 16px;"><h3 style="font-size: 16px; font-weight: 600; margin-bottom: 12px;">Called Calls</h3>';

                if (data.calls.length === 0) {
                    html += '<div style="color: #6b7280; font-style: italic;">No calls recorded</div>';
                } else {
                    html += '<div style="display: flex; flex-direction: column; gap: 8px;">';
                    data.calls.forEach(function(call) {
                        const statusColor = call.status === 'completed' ? '#059669' :
                                          call.status === 'missed' ? '#dc2626' : '#6b7280';

                        html += `
                            <div style="border: 1px solid #e5e7eb; border-radius: 6px; padding: 12px; background: #f9fafb;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <span style="font-weight: 600;">${call.direction === 'outbound' ? '↗️ Outbound' : '↙️ Inbound'}</span>
                                        <span style="color: #6b7280; margin-left: 8px;">${call.phone_number}</span>
                                    </div>
                                    <span style="color: ${statusColor}; font-size: 12px; font-weight: 500;">${call.status}</span>
                                </div>
                                <div style="color: #6b7280; font-size: 12px; margin-top: 4px;">
                                    ${new Date(call.call_date).toLocaleString()} • ${call.duration_seconds || 0}s
                                    ${call.ai_overall_score ? `• AI Score: ${Math.round(call.ai_overall_score)}/100` : ''}
                                </div>
                                ${call.transcript_status === 'completed' ? '<div style="color: #10b981; font-size: 12px; margin-top: 4px;">✓ Transcript Available</div>' : ''}
                            </div>
                        `;
                    });
                    html += '</div>';
                }

                html += '</div>';
                container.innerHTML = html;
            });
        }
    };

    // Expose to global scope
    window.LeadM8CallSystem = LeadM8CallSystem;

})(window);

import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { Map, Home, Brain, AlertCircle, X, RefreshCw, Wifi, WifiOff, Target, Clock, Settings, Shield, GitCompareArrows, Plus, Minimize2, Maximize2, Database, Combine, TreePine } from 'lucide-react';
import { isPlotListed, markPlotListed, getDeletedBlacklist } from '@/services/LandMatchingService';
import { lookupOwnerFromSheet, importPlotsFromSheet } from '@/services/SheetSyncService';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';
import xEstateLogo from '@/assets/X-Estate_Logo.svg';
import { addLastSeen, getLastSeen, removeLastSeen, LastSeenEntry } from '@/services/LastSeenService';
import { gisService, PlotData, generateDemoPlots, calculateFeasibility } from '@/services/DDAGISService';
import { loadManualLands, manualLandToPlotData, deleteManualLand, ManualLandEntry } from '@/services/ManualLandService';
import { Header } from './Header';
import { LeafletMap } from './LeafletMap';
import { DecisionConfidence } from './DecisionConfidence';
import { AIAssistant } from './AIAssistant';
import { PlotDetailPanel } from './PlotDetailPanel';
import { SearchFilters, FilterState } from './SearchFilters';
import { PlotListItem } from './PlotListItem';
import { LandMatchingWizard } from './LandMatchingWizard';
import { FeasibilitySettings } from './FeasibilitySettings';
import { ManualLandForm } from './ManualLandForm';
import { ListingsPage } from './ListingsPage';
import { AIComparativeAnalysis } from './AIComparativeAnalysis';
import { QuickAddLandModal } from './QuickAddLandModal';
import { LandAssemblyIntelligence } from './LandAssemblyIntelligence';
import { UrbanContextAnalysis } from './UrbanContextAnalysis';
import { FallbackUploadModal } from './FallbackUploadModal';
import { FeasibilityParams, DEFAULT_FEASIBILITY_PARAMS } from './FeasibilityCalculator';
import {
  VillaIntelligenceEngine,
  applyVillaFilters,
  plotsToVillaInputs,
  resolveAmenities,
} from '@/services/VillaIntelligenceEngine';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

const SQM_TO_SQFT = 10.7639;

const TABS = [
  { id: 'map', icon: Map, label: 'Map' },
  { id: 'feasibility', icon: Shield, label: 'Decision' },
  { id: 'assembly', icon: Combine, label: 'Assembly' },
  { id: 'urban', icon: TreePine, label: 'Urban' },
  { id: 'settings', icon: Settings, label: 'Settings' },
];

export function HyperPlotAI() {
  const [activeTab, setActiveTab] = useState('map');
  const [selectedPlot, setSelectedPlot] = useState<PlotData | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [highlightedPlots, setHighlightedPlots] = useState<string[]>([]);
  const [plots, setPlots] = useState<PlotData[]>([]);
  const [isLoadingGIS, setIsLoadingGIS] = useState(false);
  const [gisConnected, setGisConnected] = useState(false);
  const [gisError, setGisError] = useState<string | null>(null);
  const [loadProgress, setLoadProgress] = useState(0);
  const [showDetailPanel, setShowDetailPanel] = useState(false);
  const [showWizard, setShowWizard] = useState(false);
  const [showFeasibilitySettings, setShowFeasibilitySettings] = useState(false);
  const [showManualLandForm, setShowManualLandForm] = useState(false);
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [showFallbackUpload, setShowFallbackUpload] = useState(false);
  const [editingManualLand, setEditingManualLand] = useState<ManualLandEntry | null>(null);
  const [decisionFullscreen, setDecisionFullscreen] = useState(false);
  const [lastSeen, setLastSeen] = useState<LastSeenEntry[]>(getLastSeen());
  const [comparisonPlots, setComparisonPlots] = useState<PlotData[]>([]);
  const [sharedFeasibilityParams, setSharedFeasibilityParams] = useState<FeasibilityParams>(DEFAULT_FEASIBILITY_PARAMS);
  const [bottomPanel, setBottomPanel] = useState<'recent' | 'listings'>('recent');
  const [bottomPanelMinimized, setBottomPanelMinimized] = useState(false);
  const [bottomPanelMaximized, setBottomPanelMaximized] = useState(false);
  const [listingsRefreshKey, setListingsRefreshKey] = useState(0);
  const plotsListRef = useRef<HTMLDivElement>(null);
  const [filters, setFilters] = useState<FilterState>({
    status: [],
    zoning: [],
    minArea: null,
    maxArea: null,
    minGFA: null,
    maxGFA: null
  });

  // ── Villa Intelligence Engine ──────────────────────────────────────────────
  // Built once when plots load; auto-selects community amenities by GPS location.
  const villaEngine = useMemo(() => {
    if (plots.length === 0) return null;
    const inputs = plotsToVillaInputs(plots);
    // Pick amenity set closest to centroid of loaded plots
    const midLat = plots.reduce((s, p) => s + p.y, 0) / plots.length;
    const midLng = plots.reduce((s, p) => s + p.x, 0) / plots.length;
    const amenities = resolveAmenities(midLat, midLng);
    return new VillaIntelligenceEngine(inputs, amenities);
  }, [plots]);

  // Map of plotId → VillaIntelTags — lazily computed, cached inside engine
  const villaTagsMap = useMemo(() => {
    if (!villaEngine || plots.length === 0) return new Map();
    return villaEngine.analyzeAll(plotsToVillaInputs(plots));
  }, [villaEngine, plots]);

  // Auto-scroll to selected plot in sidebar
  useEffect(() => {
    if (!selectedPlot || !plotsListRef.current) return;
    const el = plotsListRef.current.querySelector(`[data-plot-id="${selectedPlot.id}"]`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [selectedPlot]);

  useEffect(() => {
    loadGISData();
  }, []);

  // Load manual lands from localStorage
  const mergeManualLands = useCallback((basePlots: PlotData[]) => {
    const manualLands = loadManualLands().map(manualLandToPlotData);
    const gisIds = new Set(basePlots.map(p => p.id));
    const newManual = manualLands.filter(m => !gisIds.has(m.id));
    return [...basePlots, ...newManual];
  }, []);

  async function loadGISData() {
    setIsLoadingGIS(true);
    setGisError(null);
    setLoadProgress(0);

    try {
      const isConnected = await gisService.testConnection();
      setGisConnected(isConnected);

      const progressInterval = setInterval(() => {
        setLoadProgress(prev => Math.min(prev + 10, 90));
      }, 200);

      // fetchPlots handles GIS failure internally — falls back to fallback DB
      const gisPlots = await gisService.fetchPlots(500);

      clearInterval(progressInterval);
      setLoadProgress(100);

      if (gisPlots && gisPlots.length > 0) {
        setPlots(mergeManualLands(gisPlots));
        // If GIS test failed but fallback plots loaded, show partial status
        if (!isConnected) {
          setGisError('GIS unavailable — showing fallback database plots');
        }
      } else {
        throw new Error('No plot data received');
      }

      setTimeout(() => setLoadProgress(0), 500);
    } catch (error) {
      console.error('Failed to load GIS data:', error);
      setGisError(error instanceof Error ? error.message : 'Unknown error');
      setGisConnected(false);

      const demoPlots = generateDemoPlots();
      setPlots(mergeManualLands(demoPlots));
    } finally {
      setIsLoadingGIS(false);
    }
  }

  const handleManualLandSaved = useCallback((manualPlots: PlotData[]) => {
    setPlots(prev => {
      const nonManual = prev.filter(p => p.verificationSource !== 'Manual');
      return [...nonManual, ...manualPlots];
    });
  }, []);

  const handleEditManualLand = useCallback((plot: PlotData) => {
    const manualId = plot.rawAttributes?._manualId || plot.id;
    const allManual = loadManualLands();
    const entry = allManual.find(l => l.id === manualId || l.plotNumber === plot.id);
    if (entry) {
      setEditingManualLand(entry);
      setShowManualLandForm(true);
    }
  }, []);

  const handleDeleteManualLand = useCallback((plot: PlotData) => {
    const manualId = plot.rawAttributes?._manualId || plot.id;
    const allManual = loadManualLands();
    const entry = allManual.find(l => l.id === manualId || l.plotNumber === plot.id);
    if (entry) {
      if (window.confirm(`Delete manual land "${entry.plotNumber || entry.id}"?`)) {
        deleteManualLand(entry.id);
        removeLastSeen(plot.id);
        setLastSeen(getLastSeen());
        setPlots(prev => prev.filter(p => p.id !== plot.id));
        if (selectedPlot?.id === plot.id) {
          setSelectedPlot(null);
          setShowDetailPanel(false);
        }
      }
    }
  }, [selectedPlot]);

  // ── Filtered Plots ─────────────────────────────────────────────────────────
  // Layer 1: text search + status + zoning + area/GFA
  // Layer 2: villa intelligence (layout, position, back facing, vastu, amenities)
  const filteredPlots = useMemo(() => {
    // Check if any villa intelligence filter is active
    const hasVillaFilters =
      !!filters.layoutType || !!filters.position || !!filters.backFacing ||
      !!filters.vastuCompliant || !!filters.vastuDirection ||
      (filters.nearAmenity?.length ?? 0) > 0;

    // ── Base layer: standard attribute filters ─────────────────────────────
    const base = plots.filter(plot => {
      // Text search — plot id, zoning, developer, project, location
      if (searchQuery) {
        const q = searchQuery.toLowerCase();
        const textMatch =
          plot.id.toLowerCase().includes(q) ||
          plot.zoning.toLowerCase().includes(q) ||
          (plot.developer && plot.developer.toLowerCase().includes(q)) ||
          (plot.project  && plot.project.toLowerCase().includes(q)) ||
          (plot.location && plot.location.toLowerCase().includes(q));
        // Also run NL query through villa tags if available
        const villaTagMatch = villaTagsMap.size > 0 &&
          (villaTagsMap.get(plot.id)?.smartTags.some(t => t.toLowerCase().includes(q)) ?? false);
        if (!textMatch && !villaTagMatch) return false;
      }
      if (filters.status.length > 0 && !filters.status.includes(plot.status))           return false;
      if (filters.zoning.length > 0 && !filters.zoning.includes(plot.zoning))           return false;
      if (filters.minArea !== null && plot.area < filters.minArea * 0.98)                return false;
      if (filters.maxArea !== null && plot.area > filters.maxArea * 1.02)                return false;
      if (filters.minGFA  !== null && plot.gfa  < filters.minGFA)                       return false;
      if (filters.maxGFA  !== null && plot.gfa  > filters.maxGFA)                       return false;
      return true;
    });

    // ── Villa intelligence layer ───────────────────────────────────────────
    if (hasVillaFilters && villaTagsMap.size > 0) {
      const results = applyVillaFilters(villaTagsMap, base, {
        layoutType:     filters.layoutType,
        position:       filters.position    as 'Corner' | 'EndUnit' | undefined,
        backFacing:     filters.backFacing  as 'Park' | 'Road' | 'OpenLand' | undefined,
        vastuCompliant: filters.vastuCompliant,
        vastuDirection: filters.vastuDirection,
        nearAmenity:    filters.nearAmenity as import('@/services/VillaIntelligenceEngine').AmenityType[] | undefined,
        maxAmenityDist: filters.maxAmenityDist,
      });
      return results.map(r => r.plot);
    }

    return base;
  }, [plots, searchQuery, filters, villaTagsMap]);

  useEffect(() => {
    if (selectedPlot) {
      setHighlightedPlots([selectedPlot.id]);
    } else if (searchQuery || filters.status.length > 0 || filters.zoning.length > 0) {
      setHighlightedPlots(filteredPlots.map(p => p.id));
    } else {
      setHighlightedPlots([]);
    }
  }, [selectedPlot, searchQuery, filters, filteredPlots]);

  const saveLastSeen = useCallback((plot: PlotData) => {
    if (plot.x === 0 && plot.y === 0) return;
    addLastSeen({
      plotId: plot.id,
      plotName: plot.project || plot.id,
      location: plot.location || '',
      coordinates: { x: plot.x, y: plot.y },
      area: plot.area,
      gfa: plot.gfa,
      zoning: plot.zoning,
      status: plot.status,
    });
    setLastSeen(getLastSeen());
  }, []);

  const handlePlotClick = useCallback((plot: PlotData, goToMap = false) => {
    // Force re-trigger by clearing first (handles re-selecting same plot from recent)
    setSelectedPlot(null);
    requestAnimationFrame(() => {
      setSelectedPlot(plot);
      setShowDetailPanel(true);
      saveLastSeen(plot);
      if (goToMap) {
        setActiveTab('map');
      }
    });
  }, [saveLastSeen]);

  const handlePlotFound = useCallback((plot: PlotData) => {
    setPlots(prev => {
      if (prev.find(p => p.id === plot.id)) return prev;
      return [...prev, plot];
    });
    // Force re-trigger for same plot
    setSelectedPlot(null);
    requestAnimationFrame(() => {
      setSelectedPlot(plot);
      setShowDetailPanel(true);
      setActiveTab('map');
      saveLastSeen(plot);
    });
  }, [saveLastSeen]);

  const handleCloseDetailPanel = useCallback(() => {
    setShowDetailPanel(false);
  }, []);

  const handleQuickAddDone = useCallback((_plotId: string, _ownerName?: string, _mobile?: string, plot?: PlotData) => {
    // If GIS plot was fetched, add it to plots array
    if (plot) {
      setPlots(prev => {
        if (prev.find(p => p.id === plot.id)) return prev;
        return [...prev, plot];
      });
    }
    setBottomPanel('listings');
    // Trigger ListingsPage to re-read overrides from localStorage
    setListingsRefreshKey(k => k + 1);
  }, []);

  const handleQuickAddFromPlot = useCallback((plot: PlotData) => {
    markPlotListed(plot.id);
    // Save override data from plot
    try {
      const stored = localStorage.getItem('hyperplot_listing_overrides');
      const overrides = stored ? JSON.parse(stored) : {};
      if (!overrides[plot.id]) {
        overrides[plot.id] = {};
      }
      localStorage.setItem('hyperplot_listing_overrides', JSON.stringify(overrides));
    } catch { }
    setBottomPanel('listings');
    setListingsRefreshKey(k => k + 1);
    toast({ title: 'Listed', description: `${plot.id} added to listings.` });

    // Look up owner/contact from Google Sheet in the background
    lookupOwnerFromSheet(plot.id).then(result => {
      if (result && (result.owner || result.mobile)) {
        try {
          const stored = localStorage.getItem('hyperplot_listing_overrides');
          const overrides = stored ? JSON.parse(stored) : {};
          overrides[plot.id] = {
            ...(overrides[plot.id] || {}),
            owner: result.owner || overrides[plot.id]?.owner,
            contact: result.mobile || overrides[plot.id]?.contact,
          };
          localStorage.setItem('hyperplot_listing_overrides', JSON.stringify(overrides));
          setListingsRefreshKey(k => k + 1);
          toast({ title: 'Owner Found', description: `Owner details for ${plot.id} pulled from Google Sheet.` });
        } catch { }
      }
    }).catch(() => { });
  }, []);

  // Recent entries as table data
  const recentWithPlots = useMemo(() => {
    return lastSeen.map(entry => {
      const matchedPlot = plots.find(p => p.id === entry.plotId);
      return { entry, plot: matchedPlot };
    });
  }, [lastSeen, plots]);

  // Determine grid columns based on maximize state
  const showRightSidebar = !bottomPanelMaximized;
  const mainColSpan = showRightSidebar ? 'col-span-7' : 'col-span-11';

  return (
    <div className="h-screen bg-background text-foreground flex flex-col overflow-hidden">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-xl shrink-0 z-50">
        <div className="px-6 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <img src={xEstateLogo} alt="X-Estate Logo" className="w-12 h-12" />
              <div>
                <h1 className="text-xl font-bold gradient-text">Land OS</h1>
                <p className="text-sm text-muted-foreground">DDA GIS Dashboard</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Connection Status */}
              <div className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${gisConnected
                ? 'bg-success/20 text-success border border-success/30'
                : plots.length > 0 && plots.some(p => (p.rawAttributes as Record<string,unknown>)?._isFallbackPlot)
                  ? 'bg-primary/20 text-primary border border-primary/30'
                  : 'bg-warning/20 text-warning border border-warning/30'
                }`}>
                {gisConnected ? (
                  <>
                    <Wifi className="w-3.5 h-3.5" />
                    Live Data
                  </>
                ) : plots.length > 0 && plots.some(p => (p.rawAttributes as Record<string,unknown>)?._isFallbackPlot) ? (
                  <>
                    <Database className="w-3.5 h-3.5" />
                    Fallback DB
                  </>
                ) : (
                  <>
                    <WifiOff className="w-3.5 h-3.5" />
                    Demo Mode
                  </>
                )}
              </div>

              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowWizard(true)}
                className="gap-2"
              >
                <Target className="w-4 h-4" />
                Matching Wizard
              </Button>

              <Button
                variant="outline"
                size="sm"
                onClick={loadGISData}
                disabled={isLoadingGIS}
                className="gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${isLoadingGIS ? 'animate-spin' : ''}`} />
                {isLoadingGIS ? 'Loading...' : 'Refresh'}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Progress Bar */}
      {isLoadingGIS && loadProgress > 0 && (
        <div className="bg-card/50 border-b border-border/50">
          <div className="container mx-auto px-6 py-2">
            <div className="flex items-center gap-3">
              <div className="flex-1 bg-muted/50 rounded-full h-2">
                <div
                  className="h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${loadProgress}%`,
                    background: 'linear-gradient(90deg, hsl(var(--primary)), hsl(var(--secondary)))'
                  }}
                />
              </div>
              <span className="text-xs text-primary font-mono">{loadProgress}%</span>
            </div>
          </div>
        </div>
      )}

      {/* Error Banner */}
      {gisError && (
        <div className="bg-warning/10 border-b border-warning/30">
          <div className="container mx-auto px-6 py-2 flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-warning" />
              <span className="text-warning">{gisError} - Using demo data</span>
            </div>
            <button onClick={() => setGisError(null)} className="text-warning hover:text-warning/80">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      {decisionFullscreen && activeTab === 'feasibility' && selectedPlot ? (
        <div className="flex-1 min-h-0 overflow-hidden">
          <DecisionConfidence plot={selectedPlot} comparisonPlots={comparisonPlots} isFullscreen onToggleFullscreen={() => setDecisionFullscreen(false)} onExitComparison={() => setComparisonPlots([])} sharedFeasibilityParams={sharedFeasibilityParams} onFeasibilityParamsChange={setSharedFeasibilityParams} />
        </div>
      ) : (
        <div className="px-4 py-4 flex-1 min-h-0 overflow-hidden">
          <div className="grid grid-cols-12 gap-4 h-full overflow-hidden">
            {/* Sidebar Navigation */}
            <div className="col-span-1 space-y-2">
              {TABS.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full p-3 rounded-xl flex flex-col items-center gap-1.5 transition-all ${activeTab === tab.id
                    ? 'shadow-lg'
                    : 'bg-muted/30 hover:bg-muted/50'
                    }`}
                  style={activeTab === tab.id ? {
                    background: 'linear-gradient(135deg, hsl(var(--primary)), hsl(var(--secondary)))'
                  } : undefined}
                >
                  <tab.icon className="w-6 h-6" />
                  <span className="text-xs font-semibold">{tab.label}</span>
                </button>
              ))}
            </div>

            {/* Main Panel */}
            <div className={`${mainColSpan} relative h-full overflow-hidden flex flex-col gap-4`}>
              {/* Top: Main content area */}
              <div className="flex-1 min-h-0 relative overflow-hidden">
                {activeTab === 'map' && (
                  <div className="h-full glass-card glow-border overflow-hidden">
                    <LeafletMap
                      plots={filteredPlots}
                      selectedPlot={selectedPlot}
                      onPlotClick={handlePlotClick}
                      highlightedPlots={highlightedPlots}
                    />
                  </div>
                )}
                {activeTab === 'feasibility' && comparisonPlots.length >= 2 ? (
                  <AIComparativeAnalysis
                    plotA={comparisonPlots[0]}
                    plotB={comparisonPlots[1]}
                    onClose={() => setComparisonPlots([])}
                  />
                ) : activeTab === 'feasibility' && selectedPlot ? (
                  <DecisionConfidence plot={selectedPlot} comparisonPlots={comparisonPlots} isFullscreen={false} onToggleFullscreen={() => setDecisionFullscreen(true)} onExitComparison={() => setComparisonPlots([])} sharedFeasibilityParams={sharedFeasibilityParams} onFeasibilityParamsChange={setSharedFeasibilityParams} />
                ) : activeTab === 'feasibility' ? (
                  <div className="h-full flex items-center justify-center glass-card glow-border">
                    <div className="text-center">
                      <Shield className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                      <h3 className="text-lg font-bold mb-1">Select a Plot</h3>
                      <p className="text-sm text-muted-foreground">Choose a plot to view Decision Confidence</p>
                    </div>
                  </div>
                ) : null}
                {activeTab === 'assembly' && selectedPlot ? (
                  <LandAssemblyIntelligence
                    plot={selectedPlot}
                    onSelectPlot={(p) => {
                      setPlots(prev => prev.find(pp => pp.id === p.id) ? prev : [...prev, p]);
                      setSelectedPlot(p);
                      setShowDetailPanel(true);
                    }}
                    onClose={() => setActiveTab('map')}
                  />
                ) : activeTab === 'assembly' ? (
                  <div className="h-full flex items-center justify-center glass-card glow-border">
                    <div className="text-center">
                      <Combine className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                      <h3 className="text-lg font-bold mb-1">Select a Plot</h3>
                      <p className="text-sm text-muted-foreground">Choose a plot to view Land Assembly Intelligence</p>
                    </div>
                  </div>
                ) : null}
                {activeTab === 'urban' && selectedPlot ? (
                  <UrbanContextAnalysis
                    plot={selectedPlot}
                    onClose={() => setActiveTab('map')}
                  />
                ) : activeTab === 'urban' ? (
                  <div className="h-full flex items-center justify-center glass-card glow-border">
                    <div className="text-center">
                      <TreePine className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
                      <h3 className="text-lg font-bold mb-1">Select a Plot</h3>
                      <p className="text-sm text-muted-foreground">Choose a plot to view Urban Context Analysis</p>
                    </div>
                  </div>
                ) : null}
                {activeTab === 'settings' && (
                  <div className="h-full glass-card glow-border p-6 overflow-y-auto">
                    <div className="flex items-center gap-3 mb-6">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                        style={{ background: 'linear-gradient(135deg, hsl(var(--primary)), hsl(var(--secondary)))' }}>
                        <Settings className="w-5 h-5 text-background" />
                      </div>
                      <div>
                        <h3 className="font-bold text-foreground text-lg">Settings Wizard</h3>
                        <p className="text-xs text-muted-foreground">Configure area research, plots, and data sources</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <button
                        onClick={() => setShowFeasibilitySettings(true)}
                        className="glass-card p-5 rounded-xl text-left hover:bg-muted/50 transition-all group"
                      >
                        <Settings className="w-8 h-8 text-primary mb-3 group-hover:scale-110 transition-transform" />
                        <h4 className="font-semibold text-sm mb-1">Area Research & Settings</h4>
                        <p className="text-xs text-muted-foreground">Upload area docs, configure Google Sheets, and manage plot data</p>
                      </button>
                      <button
                        onClick={() => setShowFallbackUpload(true)}
                        className="glass-card p-5 rounded-xl text-left hover:bg-muted/50 transition-all group"
                      >
                        <Database className="w-8 h-8 text-primary mb-3 group-hover:scale-110 transition-transform" />
                        <h4 className="font-semibold text-sm mb-1">Fallback DB</h4>
                        <p className="text-xs text-muted-foreground">Upload CSV to fallback database for offline GIS coverage</p>
                      </button>
                      <button
                        onClick={() => setShowManualLandForm(true)}
                        className="glass-card p-5 rounded-xl text-left hover:bg-muted/50 transition-all group"
                      >
                        <Plus className="w-8 h-8 text-primary mb-3 group-hover:scale-110 transition-transform" />
                        <h4 className="font-semibold text-sm mb-1">Add Manual Plot</h4>
                        <p className="text-xs text-muted-foreground">Manually add a plot with location and planning data</p>
                      </button>
                    </div>
                  </div>
                )}

                {/* Floating Detail Panel */}
                {showDetailPanel && selectedPlot && (
                  <PlotDetailPanel
                    plot={selectedPlot}
                    onClose={handleCloseDetailPanel}
                    onSelectPlot={handlePlotFound}
                    sharedFeasibilityParams={sharedFeasibilityParams}
                    onFeasibilityParamsChange={setSharedFeasibilityParams}
                    refreshKey={listingsRefreshKey}
                    onGoToLocation={(plot) => {
                      setActiveTab('map');
                      // Reset selected plot to trigger re-animation, even if it's the same plot
                      if (selectedPlot?.id === plot.id) {
                        setSelectedPlot(null);
                        setTimeout(() => setSelectedPlot(plot), 300);
                      } else {
                        setSelectedPlot(plot);
                      }
                      // Ensure the detail panel is closed when going to map
                      setShowDetailPanel(false);
                    }}
                  />
                )}
              </div>

              {/* Bottom: Recent / Listings toggle panel */}
              <div className={`${bottomPanelMinimized ? 'h-[40px]' : bottomPanelMaximized ? 'h-[500px]' : 'h-[260px]'} shrink-0 glass-card glow-border overflow-hidden flex flex-col transition-all`}>
                {/* Toggle tabs */}
                <div className="flex items-center border-b border-border/50 shrink-0">
                  <button
                    onClick={() => setBottomPanel('recent')}
                    className={`flex-1 px-4 py-2.5 text-xs font-semibold uppercase tracking-wide transition-colors ${bottomPanel === 'recent'
                      ? 'text-primary border-b-2 border-primary'
                      : 'text-muted-foreground hover:text-foreground'
                      }`}
                  >
                    <span className="flex items-center justify-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      Recent ({lastSeen.length})
                    </span>
                  </button>
                  <button
                    onClick={() => setBottomPanel('listings')}
                    className={`flex-1 px-4 py-2.5 text-xs font-semibold uppercase tracking-wide transition-colors ${bottomPanel === 'listings'
                      ? 'text-primary border-b-2 border-primary'
                      : 'text-muted-foreground hover:text-foreground'
                      }`}
                  >
                    <span className="flex items-center justify-center gap-1.5">
                      <Home className="w-3.5 h-3.5" />
                      Listings
                    </span>
                  </button>
                  <div className="flex items-center gap-1.5 px-2">
                    <button
                      onClick={() => {
                        if (bottomPanelMinimized) {
                          setBottomPanelMinimized(false);
                        } else {
                          setBottomPanelMinimized(true);
                          setBottomPanelMaximized(false);
                        }
                      }}
                      className="p-1 rounded hover:bg-muted/50 text-muted-foreground hover:text-foreground transition-all"
                      title={bottomPanelMinimized ? 'Restore' : 'Minimize'}
                    >
                      <Minimize2 className="w-3.5 h-3.5" />
                    </button>
                    {/* Fullscreen toggle */}
                    <button
                      onClick={() => {
                        if (bottomPanelMaximized) {
                          setBottomPanelMaximized(false);
                        } else {
                          setBottomPanelMaximized(true);
                          setBottomPanelMinimized(false);
                        }
                      }}
                      className="p-1 rounded hover:bg-muted/50 text-muted-foreground hover:text-foreground transition-all"
                      title={bottomPanelMaximized ? 'Exit Full Screen' : 'Full Screen'}
                    >
                      <Maximize2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Panel content */}
                {!bottomPanelMinimized && (
                  <div className="flex-1 min-h-0 overflow-hidden p-3">
                    {bottomPanel === 'recent' && (
                      <ScrollArea className="h-full">
                        {lastSeen.length === 0 ? (
                          <div className="text-center py-8 text-muted-foreground">
                            <Clock className="w-8 h-8 mx-auto mb-3 opacity-20" />
                            <p className="text-sm font-medium">No recent plots</p>
                            <p className="text-xs mt-1 opacity-60">Search or click a plot to start tracking</p>
                          </div>
                        ) : (
                          <div className="min-w-[600px]">
                            <Table>
                              <TableHeader>
                                <TableRow className="border-border/30">
                                  <TableHead className="font-semibold text-sm text-muted-foreground tracking-wide">Land Number</TableHead>
                                  <TableHead className="font-semibold text-sm text-muted-foreground tracking-wide">Location</TableHead>
                                  <TableHead className="font-semibold text-sm text-muted-foreground tracking-wide">Area (sqft)</TableHead>
                                  <TableHead className="font-semibold text-sm text-muted-foreground tracking-wide">GFA (sqft)</TableHead>
                                  <TableHead className="font-semibold text-sm text-muted-foreground tracking-wide">Zoning</TableHead>
                                  <TableHead className="font-semibold text-sm text-muted-foreground tracking-wide">Status</TableHead>
                                  <TableHead className="font-semibold text-sm text-muted-foreground tracking-wide">Viewed</TableHead>
                                </TableRow>
                              </TableHeader>
                              <TableBody>
                                {recentWithPlots.map(({ entry, plot: matchedPlot }) => (
                                  <TableRow
                                    key={entry.plotId}
                                    className="cursor-pointer hover:bg-primary/5 transition-all duration-200 border-border/20"
                                    onClick={async () => {
                                      if (matchedPlot) {
                                        handlePlotClick(matchedPlot, true);
                                      } else {
                                        try {
                                          const fetched = await gisService.fetchPlotById(entry.plotId);
                                          if (fetched) { handlePlotFound(fetched); return; }
                                        } catch { /* continue to fallback reconstruction */ }
                                        const reconstructed: PlotData = {
                                          id: entry.plotId,
                                          x: entry.coordinates.x,
                                          y: entry.coordinates.y,
                                          area: entry.area,
                                          gfa: entry.gfa,
                                          zoning: entry.zoning,
                                          status: entry.status,
                                          location: entry.location,
                                          project: entry.plotName,
                                          floors: '',
                                          developer: '',
                                          color: '',
                                          constructionCost: 0,
                                          salePrice: 0,
                                          isFrozen: false,
                                          verificationSource: 'DLD' as const,
                                          rawAttributes: {
                                            _isFallbackPlot: true,
                                            _isManualLatLng: true,
                                          }
                                        };
                                        handlePlotFound(reconstructed);
                                      }
                                    }}
                                  >
                                    <TableCell className="font-bold text-sm text-foreground">{entry.plotId}</TableCell>
                                    <TableCell className="text-sm text-muted-foreground">{entry.location || '—'}</TableCell>
                                    <TableCell className="font-mono text-sm tabular-nums">{Math.round(entry.area * SQM_TO_SQFT).toLocaleString()}</TableCell>
                                    <TableCell className="font-mono text-sm tabular-nums">{Math.round(entry.gfa * SQM_TO_SQFT).toLocaleString()}</TableCell>
                                    <TableCell>
                                      <Badge variant="outline" className="text-xs font-medium px-2 py-0.5">{entry.zoning}</Badge>
                                    </TableCell>
                                    <TableCell>
                                      <Badge
                                        variant="outline"
                                        className={`text-xs font-medium px-2 py-0.5 ${
                                          entry.status === 'Available' ? 'border-success/40 text-success bg-success/10' :
                                          entry.status === 'Frozen' ? 'border-destructive/40 text-destructive bg-destructive/10' :
                                          'border-border'
                                        }`}
                                      >{entry.status}</Badge>
                                    </TableCell>
                                    <TableCell className="text-xs text-muted-foreground/70 font-medium">
                                      {new Date(entry.timestamp).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' })}
                                    </TableCell>
                                  </TableRow>
                                ))}
                              </TableBody>
                            </Table>
                          </div>
                        )}
                      </ScrollArea>
                    )}

                    {bottomPanel === 'listings' && (
                      <ListingsPage
                        plots={plots}
                        onSelectPlot={(plot) => handlePlotClick(plot, true)}
                        onCreateListing={() => setShowQuickAdd(true)}
                        onListingDeleted={(plotId) => {
                          setLastSeen(getLastSeen());
                          setListingsRefreshKey(k => k + 1);
                          // Close detail panel if deleted plot is currently shown
                          if (selectedPlot?.id === plotId) {
                            setShowDetailPanel(false);
                            setSelectedPlot(null);
                          }
                        }}
                        onSyncSheet={async () => {
                          toast({ title: 'Syncing...', description: 'Importing plots from Google Sheet...' });
                          try {
                            const imported = await importPlotsFromSheet();
                            if (imported.length === 0) {
                              toast({ title: 'No Data', description: 'No plots found in Google Sheet. Check your sheet URL in settings.' });
                              return;
                            }
                            let newCount = 0;
                            const deletedBlacklist = getDeletedBlacklist();
                            const overridesRaw = localStorage.getItem('hyperplot_listing_overrides');
                            const overrides = overridesRaw ? JSON.parse(overridesRaw) : {};
                            for (const entry of imported) {
                              // Skip plots that were explicitly deleted by the user
                              if (deletedBlacklist.has(entry.plotNumber)) continue;
                              if (!isPlotListed(entry.plotNumber)) {
                                markPlotListed(entry.plotNumber);
                                newCount++;
                              }
                              // Always update all fields from sheet
                              overrides[entry.plotNumber] = {
                                ...(overrides[entry.plotNumber] || {}),
                                owner: entry.owner || overrides[entry.plotNumber]?.owner,
                                contact: entry.contact || overrides[entry.plotNumber]?.contact,
                                price: entry.price || overrides[entry.plotNumber]?.price,
                                status: entry.status || overrides[entry.plotNumber]?.status,
                                notes: entry.notes || overrides[entry.plotNumber]?.notes,
                              };
                            }
                            localStorage.setItem('hyperplot_listing_overrides', JSON.stringify(overrides));
                            setListingsRefreshKey(k => k + 1);
                            toast({ title: 'Sync Complete', description: `${imported.length} plots synced (${newCount} new). Owner/contact data updated.` });
                          } catch (err) {
                            console.error('Import error:', err);
                            toast({ title: 'Sync Failed', description: 'Could not import from Google Sheet.' });
                          }
                        }}
                        refreshKey={listingsRefreshKey}
                      />
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Right Sidebar - Search & Plots List (hidden when maximized) */}
            {showRightSidebar && (
              <div className="col-span-4 glass-card glow-border p-4 flex flex-col h-full overflow-hidden">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-bold text-base">Available Plots</h3>
                    <p className="text-sm text-muted-foreground">
                      {gisConnected ? 'Live DDA GIS Data' : plots.some(p => (p.rawAttributes as Record<string,unknown>)?._isFallbackPlot) ? 'Fallback DB' : 'Demo Mode'} • Last 3
                    </p>
                  </div>
                  <div className="px-2.5 py-1 bg-primary/20 rounded text-sm font-bold text-primary">
                    {Math.min(filteredPlots.length, 3)}
                  </div>
                </div>

                {/* Comparison Chips */}
                {comparisonPlots.length > 0 && (
                  <div className="mb-3 p-2 rounded-lg bg-primary/10 border border-primary/30">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <GitCompareArrows className="w-3.5 h-3.5 text-primary" />
                      <span className="text-xs font-bold text-primary uppercase">Compare ({comparisonPlots.length}/3)</span>
                      <button onClick={() => setComparisonPlots([])} className="ml-auto text-xs text-muted-foreground hover:text-foreground">Clear</button>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {comparisonPlots.map(p => (
                        <span key={p.id} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/20 text-xs font-medium text-primary">
                          {p.id}
                          <button onClick={() => setComparisonPlots(prev => prev.filter(cp => cp.id !== p.id))} className="hover:text-destructive">
                            <X className="w-3 h-3" />
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Search & Filters */}
                <SearchFilters
                  plots={plots}
                  onSearch={setSearchQuery}
                  onFilterChange={setFilters}
                  onPlotFound={handlePlotFound}
                />

                {/* Plots List */}
                <ScrollArea className="flex-1 mt-4">
                  <div ref={plotsListRef} className="space-y-2 pr-2">
                    {/* When comparing, show comparison plots first as a dedicated section */}
                    {comparisonPlots.length > 0 && (
                      <>
                        <div className="text-xs font-bold text-primary uppercase tracking-wide mb-1">Compared Plots</div>
                        {comparisonPlots.map(plot => (
                          <div key={`cmp-${plot.id}`} className="relative group ring-1 ring-primary/40 rounded-xl">
                            <PlotListItem
                              plot={plot}
                              isSelected={selectedPlot?.id === plot.id}
                              isHighlighted={true}
                              onClick={() => handlePlotClick(plot, true)}
                              onEdit={plot.verificationSource === 'Manual' ? handleEditManualLand : undefined}
                              onDelete={plot.verificationSource === 'Manual' ? handleDeleteManualLand : undefined}
                              onQuickAdd={isPlotListed(plot.id) ? undefined : () => handleQuickAddFromPlot(plot)}
                              villaIntel={villaTagsMap.get(plot.id)}
                            />
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setComparisonPlots(prev => prev.filter(p => p.id !== plot.id));
                              }}
                              className="absolute top-2 right-2 p-1.5 rounded-md bg-primary text-primary-foreground shadow-md transition-all"
                              title="Remove from comparison"
                            >
                              <GitCompareArrows className="w-4 h-4" />
                            </button>
                          </div>
                        ))}
                        <div className="border-b border-border/30 my-2" />
                      </>
                    )}

                    {/* Regular plot list (exclude already-compared plots) */}
                    {filteredPlots.slice(-3).reverse()
                      .filter(plot => !comparisonPlots.find(cp => cp.id === plot.id))
                      .map(plot => (
                      <div key={plot.id} className="relative group">
                        <PlotListItem
                          plot={plot}
                          isSelected={selectedPlot?.id === plot.id}
                          isHighlighted={highlightedPlots.includes(plot.id)}
                          onClick={() => handlePlotClick(plot, true)}
                          onEdit={plot.verificationSource === 'Manual' ? handleEditManualLand : undefined}
                          onDelete={plot.verificationSource === 'Manual' ? handleDeleteManualLand : undefined}
                          onQuickAdd={isPlotListed(plot.id) ? undefined : () => handleQuickAddFromPlot(plot)}
                          villaIntel={villaTagsMap.get(plot.id)}
                        />
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setComparisonPlots(prev => {
                              if (prev.find(p => p.id === plot.id)) return prev.filter(p => p.id !== plot.id);
                              if (prev.length >= 3) return prev;
                              const next = [...prev, plot];
                              if (next.length >= 2) setActiveTab('feasibility');
                              return next;
                            });
                          }}
                          className={`absolute top-2 right-2 p-1.5 rounded-md transition-all ${comparisonPlots.find(p => p.id === plot.id)
                            ? 'bg-primary text-primary-foreground shadow-md'
                            : 'bg-muted/90 text-muted-foreground opacity-100 hover:bg-primary/20 hover:text-primary'
                            }`}
                          title="Add to comparison"
                        >
                          <GitCompareArrows className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                    {filteredPlots.length === 0 && (
                      <div className="text-center py-8 text-muted-foreground">
                        <Map className="w-8 h-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No plots match your criteria</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Land Matching Wizard */}
      <LandMatchingWizard
        isOpen={showWizard}
        onClose={() => setShowWizard(false)}
        plots={plots}
        onHighlightPlots={setHighlightedPlots}
        onAddPlots={(newPlots) => {
          setPlots(prev => {
            const existingIds = new Set(prev.map(p => p.id));
            const toAdd = newPlots.filter(p => !existingIds.has(p.id));
            return toAdd.length > 0 ? [...prev, ...toAdd] : prev;
          });
        }}
        onSelectPlot={(plot) => {
          setPlots(prev => {
            if (prev.find(p => p.id === plot.id)) return prev;
            return [...prev, plot];
          });
          setSelectedPlot(plot);
          setShowDetailPanel(true);
          setActiveTab('map');
          saveLastSeen(plot);
        }}
      />

      {/* Feasibility Settings */}
      <FeasibilitySettings
        open={showFeasibilitySettings}
        onClose={() => setShowFeasibilitySettings(false)}
        onOpenAddLand={() => setShowManualLandForm(true)}
        onOpenFallbackDB={() => setShowFallbackUpload(true)}
      />

      {/* Manual Land Entry Form */}
      <ManualLandForm
        open={showManualLandForm}
        onClose={() => { setShowManualLandForm(false); setEditingManualLand(null); }}
        onLandSaved={handleManualLandSaved}
        editEntry={editingManualLand}
      />

      {/* Quick Add Land Modal */}
      <QuickAddLandModal
        open={showQuickAdd}
        onClose={() => setShowQuickAdd(false)}
        onLandAdded={handleQuickAddDone}
      />

      {/* Fallback Plot Database Upload */}
      <FallbackUploadModal
        open={showFallbackUpload}
        onClose={() => setShowFallbackUpload(false)}
      />
    </div>
  );
}
